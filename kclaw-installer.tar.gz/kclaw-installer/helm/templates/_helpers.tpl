{{/*
Expand the name of the chart.
*/}}
{{- define "kubeclaw.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Full release name capped at 63 chars.
*/}}
{{- define "kubeclaw.fullname" -}}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Chart label — name + version.
*/}}
{{- define "kubeclaw.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels applied to every resource.
*/}}
{{- define "kubeclaw.labels" -}}
helm.sh/chart: {{ include "kubeclaw.chart" . }}
app.kubernetes.io/name: {{ include "kubeclaw.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/part-of: kubeclaw
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels (stable — no chart version).
*/}}
{{- define "kubeclaw.selectorLabels" -}}
app.kubernetes.io/name: {{ include "kubeclaw.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Image pull secrets block — renders only when global.imagePullSecretName is set.
*/}}
{{- define "kubeclaw.imagePullSecrets" -}}
{{- if .Values.global.imagePullSecretName }}
imagePullSecrets:
  - name: {{ .Values.global.imagePullSecretName }}
{{- end }}
{{- end }}

{{/*
In-cluster DNS name for CredRouter (port 80 on the service).
Usage: {{ include "kubeclaw.credRouterURL" . }}
*/}}
{{- define "kubeclaw.credRouterURL" -}}
http://credrouter.{{ .Release.Namespace }}.svc.cluster.local
{{- end }}

{{/*
In-cluster DNS name for the Orchestrator Admin API (port 3002).
*/}}
{{- define "kubeclaw.orchestratorAdminURL" -}}
http://kubeclaw-admin-api.{{ .Release.Namespace }}.svc.cluster.local:{{ .Values.orchestrator.ports.adminApi }}
{{- end }}

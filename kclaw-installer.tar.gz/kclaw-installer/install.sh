#!/usr/bin/env bash
# KubeClaw — single-node multi-platform installer (arm64 + amd64)
# Run from the extracted installer directory as root: sudo ./scripts/install.sh
set -euo pipefail

# ── Colours ───────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

info()    { echo -e "${CYAN}[INFO]${RESET}  $*"; }
success() { echo -e "${GREEN}[OK]${RESET}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${RESET}  $*"; }
fatal()   { echo -e "${RED}[FATAL]${RESET} $*" >&2; exit 1; }
header()  { echo -e "\n${BOLD}${CYAN}══ $* ══${RESET}\n"; }

# ── Preflight ─────────────────────────────────────────────────────────────────
header "KubeClaw Installer"

[[ $EUID -eq 0 ]] || fatal "Run this script as root: sudo ./scripts/install.sh"
[[ -f "helm/Chart.yaml" ]] || fatal "Run from the extracted installer root: cd kubeclaw-installer && sudo ./scripts/install.sh"

# ── Architecture detection ────────────────────────────────────────────────────
ARCH=$(uname -m)
case "$ARCH" in
  x86_64)  PLATFORM="amd64" ;;
  aarch64) PLATFORM="arm64" ;;
  *) fatal "Unsupported architecture: $ARCH. KubeClaw supports x86_64 (amd64) and aarch64 (arm64)." ;;
esac
info "Detected platform: ${ARCH} (${PLATFORM})"

REPO_ROOT="$(pwd)"

# ── Pre-flight: Checklist ─────────────────────────────────────────────────────
echo
echo -e "${BOLD}Before you begin, collect the following:${RESET}"
echo
echo -e "${BOLD}LLM Provider${RESET} (choose one)"
echo "  1) Anthropic  — API key from console.anthropic.com"
echo "  2) Bedrock    — AWS Access Key ID + Secret + Region"
echo "  3) OpenRouter — API key from openrouter.ai (supports Gemini, Mistral, etc.)"
echo
echo -e "${BOLD}Required${RESET}"
echo "  • Admin email + display name (for the Admin UI login)"
echo
echo -e "${BOLD}Messaging channels${RESET} (at least one required)"
echo "  • Slack:    Bot Token (xoxb-…) + App Token (xapp-…)"
echo "  • Telegram: Bot Token (from @BotFather)"
echo
echo -e "${BOLD}Optional${RESET}"
echo "  • OpenAI API Key       — voice message transcription via Whisper"
echo "  • Brave Search API Key — web search inside agent conversations"
echo
read -rp "Ready to proceed? [y/N] " _READY
[[ "${_READY,,}" == "y" ]] || { info "Come back when you have everything. Exiting."; exit 0; }

# ── Phase 1: Collect credentials ──────────────────────────────────────────────
header "Phase 1 — Credentials"
echo "Enter your configuration. Secrets are not echoed."
echo

prompt()      { read -rp "  $1: " "$2"; }
prompt_secret(){ read -rsp "  $1: " "$2"; echo; }
prompt_default(){ read -rp "  $1 [${3}]: " "$2"; if [[ -z "${!2}" ]]; then printf -v "$2" '%s' "$3"; fi; }

prompt        "Admin email (for Admin UI login)"        ADMIN_EMAIL
prompt        "Admin display name"                       ADMIN_DISPLAY_NAME
prompt_default "Assistant name (bot trigger name)"       ASSISTANT_NAME "G-eves"
echo
echo "  Select your LLM provider:"
echo "    1) Anthropic"
echo "    2) Bedrock (AWS)"
echo "    3) OpenRouter"
read -rp "  Provider [1/2/3]: " LLM_PROVIDER_CHOICE
case "$LLM_PROVIDER_CHOICE" in
  1)
    LLM_PROVIDER="anthropic"
    prompt_secret "Anthropic API Key" ANTHROPIC_API_KEY
    [[ -n "$ANTHROPIC_API_KEY" ]] || fatal "Anthropic API Key is required."
    AWS_ACCESS_KEY_ID=""
    AWS_SECRET_ACCESS_KEY=""
    AWS_REGION=""
    OPENROUTER_API_KEY=""
    OPENROUTER_MODEL=""
    ;;
  2)
    LLM_PROVIDER="bedrock"
    prompt_secret "AWS Access Key ID"     AWS_ACCESS_KEY_ID
    prompt_secret "AWS Secret Access Key" AWS_SECRET_ACCESS_KEY
    prompt_default "AWS Region"           AWS_REGION "us-east-1"
    [[ -n "$AWS_ACCESS_KEY_ID" && -n "$AWS_SECRET_ACCESS_KEY" ]] || fatal "AWS credentials are required for Bedrock."
    ANTHROPIC_API_KEY=""
    OPENROUTER_API_KEY=""
    OPENROUTER_MODEL=""
    ;;
  3)
    LLM_PROVIDER="openrouter"
    prompt_secret "OpenRouter API Key" OPENROUTER_API_KEY
    [[ -n "$OPENROUTER_API_KEY" ]] || fatal "OpenRouter API Key is required."
    prompt_default "OpenRouter model" OPENROUTER_MODEL "google/gemini-2.5-flash"
    AWS_ACCESS_KEY_ID=""
    AWS_SECRET_ACCESS_KEY=""
    AWS_REGION=""
    ANTHROPIC_API_KEY=""
    ;;
  *)
    fatal "Invalid provider choice. Enter 1, 2, or 3."
    ;;
esac
echo
echo "  Configure at least one messaging channel:"
prompt_secret "Slack Bot Token xoxb-… (leave blank to skip)"  SLACK_BOT_TOKEN
SLACK_BOT_TOKEN="${SLACK_BOT_TOKEN//[$'\t\r\n ']/}"
prompt_secret "Slack App Token xapp-… (required if Slack token provided)" SLACK_APP_TOKEN
SLACK_APP_TOKEN="${SLACK_APP_TOKEN//[$'\t\r\n ']/}"
prompt_secret "Telegram Bot Token (leave blank to skip)"       TELEGRAM_BOT_TOKEN
TELEGRAM_BOT_TOKEN="${TELEGRAM_BOT_TOKEN//[$'\t\r\n ']/}"
echo
echo "  (optional — enables voice message transcription via Whisper)"
prompt_secret "OpenAI API Key (leave blank to skip)"           OPENAI_API_KEY
echo "  (optional — enables web search inside agent conversations)"
prompt_secret "Brave Search API Key (leave blank to skip)"     BRAVE_SEARCH_API_KEY

# Validate at least one channel
if [[ -z "$SLACK_BOT_TOKEN" && -z "$TELEGRAM_BOT_TOKEN" ]]; then
  fatal "At least one channel token (Slack or Telegram) must be provided."
fi
if [[ -n "$SLACK_BOT_TOKEN" && -z "$SLACK_APP_TOKEN" ]]; then
  fatal "SLACK_APP_TOKEN is required when SLACK_BOT_TOKEN is provided."
fi

# ── Phase 2: Generate secrets ─────────────────────────────────────────────────
header "Phase 2 — Generating Secrets"

ENCRYPTION_KEY=$(openssl rand -base64 32)
JWT_SECRET=$(openssl rand -base64 48)
ADMIN_TOKEN=$(openssl rand -hex 32)
LITELLM_MASTER_KEY="sk-litellm-$(openssl rand -hex 24)"
PG_PASSWORD=$(openssl rand -hex 16)
NODE_HOSTNAME=$(hostname)
WORKSPACE_PATH="/opt/kubeclaw/workspace"

success "Encryption key generated"
success "JWT secret generated"
success "Admin token generated"
success "LiteLLM master key generated"
success "PostgreSQL password generated"
info    "Node hostname: $NODE_HOSTNAME"

# Summary before doing anything destructive
echo
echo -e "${BOLD}Configuration summary:${RESET}"
echo "  Admin email:        $ADMIN_EMAIL"
echo "  Admin name:         $ADMIN_DISPLAY_NAME"
echo "  Assistant name:     $ASSISTANT_NAME"
echo "  LLM provider:       $LLM_PROVIDER"
[[ "$LLM_PROVIDER" == "bedrock" ]]    && echo "  AWS region:         $AWS_REGION"
[[ "$LLM_PROVIDER" == "openrouter" ]] && echo "  OpenRouter model:   $OPENROUTER_MODEL"
echo "  Slack:              $([[ -n "$SLACK_BOT_TOKEN" ]] && echo 'enabled' || echo 'disabled')"
echo "  Telegram:           $([[ -n "$TELEGRAM_BOT_TOKEN" ]] && echo 'enabled' || echo 'disabled')"
echo "  Voice transcription:$([[ -n "$OPENAI_API_KEY" ]] && echo ' enabled' || echo ' disabled (no OpenAI key)')"
echo "  Brave Search:       $([[ -n "$BRAVE_SEARCH_API_KEY" ]] && echo 'enabled' || echo 'disabled (no Brave key)')"
echo
read -rp "Proceed with installation? [y/N] " CONFIRM
[[ "${CONFIRM,,}" == "y" ]] || { info "Aborted."; exit 0; }

# ── Phase 3: System dependencies ─────────────────────────────────────────────
header "Phase 3 — System Dependencies"

export DEBIAN_FRONTEND=noninteractive

# Wait for any apt locks held by unattended-upgrades or other processes
info "Waiting for apt lock..."
while ! flock -n /var/lib/dpkg/lock-frontend true 2>/dev/null; do
  sleep 2
done
apt-get update

apt-get install -y curl jq git openssl ca-certificates

# Node.js 22 LTS (needed for admin bootstrap CLI)
NODE_MAJOR=$(node -e "process.stdout.write(process.versions.node.split('.')[0])" 2>/dev/null || echo "0")
if [[ "$NODE_MAJOR" -lt 22 ]]; then
  info "Installing Node.js 22 LTS..."
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi
success "Node.js $(node --version)"

info "Installing repo dependencies..."
npm install
success "npm install done"

# ── Phase 4: k3s ──────────────────────────────────────────────────────────────
header "Phase 4 — k3s"

if command -v k3s &>/dev/null; then
  warn "k3s already installed — skipping"
else
  info "Installing k3s..."
  curl -sfL https://get.k3s.io | sh -
  success "k3s installed"
fi

export KUBECONFIG=/etc/rancher/k3s/k3s.yaml
info "Waiting for node to register..."
until kubectl get nodes 2>/dev/null | grep -q .; do sleep 3; done
info "Waiting for node to be ready..."
kubectl wait --for=condition=ready node --all --timeout=180s
success "k3s node ready"

# ── Phase 5: Helm ─────────────────────────────────────────────────────────────
header "Phase 5 — Helm"

if ! command -v helm &>/dev/null; then
  info "Installing helm..."
  curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash >/dev/null 2>&1
  success "Helm $(helm version --short)"
else
  warn "Helm already installed — $(helm version --short)"
fi

info "Adding bitnami repo..."
helm repo add bitnami https://charts.bitnami.com/bitnami --force-update >/dev/null
helm repo update >/dev/null
success "Helm repos ready"

# ── Phase 6: Namespace + registry secret ──────────────────────────────────────
header "Phase 6 — Namespace + Registry"

kubectl create namespace kclaw   --dry-run=client -o yaml | kubectl apply -f -
kubectl create namespace postgresql --dry-run=client -o yaml | kubectl apply -f -

success "Namespaces ready"

# ── Phase 7: PostgreSQL ───────────────────────────────────────────────────────
header "Phase 7 — PostgreSQL"

helm upgrade --install postgres bitnami/postgresql \
  --namespace postgresql \
  --set auth.postgresPassword="$PG_PASSWORD" \
  --set auth.database=litellm \
  --set primary.persistence.storageClass=local-path \
  --wait --timeout=5m

PG_HOST="postgres-postgresql.postgresql.svc.cluster.local"
DATABASE_URL="postgresql://postgres:${PG_PASSWORD}@${PG_HOST}:5432/litellm"
success "PostgreSQL ready"

# ── Phase 8: LiteLLM ──────────────────────────────────────────────────────────
header "Phase 8 — LiteLLM"

LITELLM_MANIFEST=$(mktemp /tmp/litellm-XXXXXX.yaml)

# Build provider-specific LiteLLM config entries.
PROVIDER_SECRET_ENTRIES=""
PRIMARY_MODEL_ENTRY=""
SECONDARY_MODEL_ENTRY=""
FALLBACK_ROUTER=""

case "$LLM_PROVIDER" in
  anthropic)
    PROVIDER_SECRET_ENTRIES="  ANTHROPIC_API_KEY: \"${ANTHROPIC_API_KEY}\""
    PRIMARY_MODEL_ENTRY="
      - model_name: primary
        litellm_params:
          model: anthropic/claude-sonnet-4-6
          api_key: os.environ/ANTHROPIC_API_KEY"
    SECONDARY_MODEL_ENTRY="
      - model_name: claude-haiku-4-5-20251001
        litellm_params:
          model: anthropic/claude-haiku-4-5-20251001
          api_key: os.environ/ANTHROPIC_API_KEY"
    ;;
  bedrock)
    PROVIDER_SECRET_ENTRIES="  AWS_ACCESS_KEY_ID: \"${AWS_ACCESS_KEY_ID}\"
  AWS_SECRET_ACCESS_KEY: \"${AWS_SECRET_ACCESS_KEY}\"
  AWS_REGION_NAME: \"${AWS_REGION}\""
    PRIMARY_MODEL_ENTRY="
      - model_name: primary
        litellm_params:
          model: bedrock/us.anthropic.claude-sonnet-4-6
          aws_access_key_id: os.environ/AWS_ACCESS_KEY_ID
          aws_secret_access_key: os.environ/AWS_SECRET_ACCESS_KEY
          aws_region_name: os.environ/AWS_REGION_NAME"
    SECONDARY_MODEL_ENTRY="
      - model_name: claude-haiku-4-5-20251001
        litellm_params:
          model: bedrock/global.anthropic.claude-haiku-4-5-20251001-v1:0
          aws_access_key_id: os.environ/AWS_ACCESS_KEY_ID
          aws_secret_access_key: os.environ/AWS_SECRET_ACCESS_KEY
          aws_region_name: os.environ/AWS_REGION_NAME"
    ;;
  openrouter)
    PROVIDER_SECRET_ENTRIES="  OPENROUTER_API_KEY: \"${OPENROUTER_API_KEY}\""
    PRIMARY_MODEL_ENTRY="
      - model_name: primary
        litellm_params:
          model: openrouter/${OPENROUTER_MODEL}
          api_key: os.environ/OPENROUTER_API_KEY"
    SECONDARY_MODEL_ENTRY=""
    ;;
esac

cat > "$LITELLM_MANIFEST" <<YAML
---
apiVersion: v1
kind: Secret
metadata:
  name: litellm-secrets
  namespace: default
type: Opaque
stringData:
  LITELLM_MASTER_KEY: "${LITELLM_MASTER_KEY}"
  DATABASE_URL: "${DATABASE_URL}"
${PROVIDER_SECRET_ENTRIES}
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: litellm-config
  namespace: default
data:
  config.yaml: |
    model_list:
${PRIMARY_MODEL_ENTRY}
${SECONDARY_MODEL_ENTRY}
    router_settings:
      routing_strategy: least-busy
      num_retries: 3
      allowed_fails: 3
      cooldown_time: 10
    general_settings:
      master_key: os.environ/LITELLM_MASTER_KEY
      database_url: os.environ/DATABASE_URL
      store_model_in_db: true
      default_model: primary
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: litellm-deployment
  namespace: default
  labels:
    app: litellm
spec:
  replicas: 1
  selector:
    matchLabels:
      app: litellm
  template:
    metadata:
      labels:
        app: litellm
    spec:
      tolerations:
        - key: "node-role.kubernetes.io/control-plane"
          operator: "Exists"
          effect: "NoSchedule"
        - key: "node-role.kubernetes.io/master"
          operator: "Exists"
          effect: "NoSchedule"
      containers:
        - name: litellm
          image: ghcr.io/berriai/litellm:main-latest
          imagePullPolicy: Always
          ports:
            - containerPort: 4000
          args:
            - --config
            - /etc/litellm/config.yaml
            - --port
            - "4000"
          envFrom:
            - secretRef:
                name: litellm-secrets
          volumeMounts:
            - name: config
              mountPath: /etc/litellm
          resources:
            requests:
              memory: "512Mi"
              cpu: "250m"
            limits:
              memory: "2Gi"
              cpu: "1000m"
          readinessProbe:
            httpGet:
              path: /health/readiness
              port: 4000
            initialDelaySeconds: 60
            periodSeconds: 10
            timeoutSeconds: 5
            failureThreshold: 24
      volumes:
        - name: config
          configMap:
            name: litellm-config
---
apiVersion: v1
kind: Service
metadata:
  name: litellm-service
  namespace: default
spec:
  selector:
    app: litellm
  ports:
    - name: http
      port: 4000
      targetPort: 4000
  type: ClusterIP
YAML

kubectl apply -f "$LITELLM_MANIFEST"
rm -f "$LITELLM_MANIFEST"

info "Waiting for LiteLLM to be ready (image pull + Prisma migrations — up to 10 min)..."
kubectl rollout status deployment/litellm-deployment --timeout=10m
success "LiteLLM ready"

# Generate one virtual key per tenant (no model restriction — SDK uses multiple models)
info "Generating LiteLLM virtual keys..."
kubectl port-forward svc/litellm-service 4000:4000 &>/dev/null &
PF_PID=$!

# Wait for port-forward to be ready
for i in $(seq 1 15); do
  sleep 2
  if curl -sf http://localhost:4000/health/readiness &>/dev/null; then
    break
  fi
  info "Waiting for LiteLLM API to respond (attempt ${i}/15)..."
done

LITELLM_KEY_MAIN=$(curl -s -X POST http://localhost:4000/key/generate \
  -H "Authorization: Bearer ${LITELLM_MASTER_KEY}" \
  -H "Content-Type: application/json" \
  -d '{"key_alias":"main"}' | jq -r '.key')

kill $PF_PID 2>/dev/null || true

if [[ -z "$LITELLM_KEY_MAIN" || "$LITELLM_KEY_MAIN" == "null" ]]; then
  fatal "Failed to generate LiteLLM virtual key. Check LiteLLM logs: kubectl logs -l app=litellm"
fi
success "LiteLLM virtual key generated"

# ── Phase 9: KubeClaw (Helm) ──────────────────────────────────────────────────
header "Phase 9 — KubeClaw"

mkdir -p "$WORKSPACE_PATH"

VALUES_FILE=$(mktemp /tmp/values-kclaw-XXXXXX.yaml)
cat > "$VALUES_FILE" <<YAML
namespaceCreate: false

secrets:
  create: true
  credrouter:
    encryptionKey: "${ENCRYPTION_KEY}"
    jwtSecret: "${JWT_SECRET}"
  adminUiSecrets:
    jwtSecret: "${JWT_SECRET}"
    credRouterAdminToken: "${ADMIN_TOKEN}"
  channelTokens:
    slackBotToken: "${SLACK_BOT_TOKEN}"
    slackAppToken: "${SLACK_APP_TOKEN}"
    telegramBotToken: "${TELEGRAM_BOT_TOKEN}"
    openaiApiKey: "${OPENAI_API_KEY}"

credrouter:
  nodeSelector:
    kubernetes.io/hostname: "${NODE_HOSTNAME}"
  persistence:
    existingClaimName: ""
    storageClassName: local-path
    size: 1Gi

orchestrator:
  nodeSelector:
    kubernetes.io/hostname: "${NODE_HOSTNAME}"
  hostPath: "${WORKSPACE_PATH}"
  assistantName: "${ASSISTANT_NAME}"

adminUI:
  nodeSelector:
    kubernetes.io/hostname: "${NODE_HOSTNAME}"
  serviceType: LoadBalancer
  cookieSecure: "false"
  ingress:
    enabled: true
    ingressClassName: traefik
    annotations:
      traefik.ingress.kubernetes.io/router.entrypoints: web
    hosts:
      - admin.kubeclaw.local

adminApiIngress:
  enabled: true
  ingressClassName: traefik
  annotations:
    traefik.ingress.kubernetes.io/router.entrypoints: web
  hosts:
    - kubeclaw-admin.local
YAML

helm upgrade --install kubeclaw ./helm \
  --namespace kclaw \
  --values helm/values-ce.yaml \
  --values "$VALUES_FILE" \
  --wait --timeout=15m

rm -f "$VALUES_FILE"
success "KubeClaw helm release deployed"

# ── Phase 10: Agent ServiceAccount + Pod ──────────────────────────────────────
header "Phase 10 — Agent"

kubectl apply -f k8s/agent-serviceaccount.yaml -n kclaw
[[ -n "$TELEGRAM_BOT_TOKEN" ]] && kubectl apply -f k8s/agent-deployment.yaml -n kclaw
success "Agent ServiceAccount and pod created"

# ── Phase 11: CredRouter Database Bootstrap ───────────────────────────────────
header "Phase 11 — CredRouter Bootstrap"

info "Waiting for CredRouter to be ready..."
kubectl wait --for=condition=ready pod -l app=credrouter -n kclaw --timeout=60s

LITELLM_BASE_URL="http://litellm-service.default.svc.cluster.local:4000"
CREDROUTER_POD=$(kubectl get pods -n kclaw -l app=credrouter -o jsonpath='{.items[0].metadata.name}')
chmod +x k8s/credrouter/scripts/create-tenant-serviceaccount.sh

bootstrap_tenant() {
  local TENANT_ID="$1"
  local TENANT_NAME="$2"

  BOOTSTRAP_JS=$(mktemp /tmp/credrouter-bootstrap-XXXXXX.mjs)

  cat > "$BOOTSTRAP_JS" <<JSEOF
import { initDatabase } from '/app/dist/db/client.js';
import { createTenant } from '/app/dist/db/tenants.js';
import { createProviderConfig } from '/app/dist/db/provider-configs.js';
import { createToolConfig } from '/app/dist/db/tool-configs.js';
import { setSetting } from '/app/dist/db/system-settings.js';

initDatabase();

setSetting('litellm_key_main', '${LITELLM_KEY_MAIN}');
setSetting('litellm_base_url', '${LITELLM_BASE_URL}');

const tenant = createTenant('${TENANT_NAME}', '${TENANT_ID}', 1000000, 30000000);
console.log('Tenant created:', tenant.id);

createProviderConfig({
  tenantId: tenant.id,
  provider: 'litellm',
  modelId: 'primary',
  authType: 'api_key',
  apiKey: '${LITELLM_KEY_MAIN}',
  baseUrl: '${LITELLM_BASE_URL}',
  maxInputTokens: 1000000,
  maxOutputTokens: 8192,
  costPerInputToken: 0,
  costPerOutputToken: 0,
  isDefault: true,
  priority: 0,
});
console.log('LiteLLM provider config created');
JSEOF

  if [[ "$LLM_PROVIDER" == "bedrock" && -n "$ANTHROPIC_API_KEY" ]]; then
    cat >> "$BOOTSTRAP_JS" <<JSEOF

createProviderConfig({
  tenantId: tenant.id,
  provider: 'anthropic',
  modelId: 'claude-sonnet-4-6',
  authType: 'api_key',
  apiKey: '${ANTHROPIC_API_KEY}',
  baseUrl: 'https://api.anthropic.com',
  maxInputTokens: 200000,
  maxOutputTokens: 8192,
  costPerInputToken: 0.000003,
  costPerOutputToken: 0.000015,
  isDefault: false,
  priority: 1,
});
console.log('Anthropic fallback provider config created');
JSEOF
  fi

  if [[ -n "$BRAVE_SEARCH_API_KEY" ]]; then
    cat >> "$BOOTSTRAP_JS" <<JSEOF

createToolConfig(tenant.id, 'brave-search', { apiKey: '${BRAVE_SEARCH_API_KEY}' });
console.log('Brave Search tool config created');
JSEOF
  fi

  cat >> "$BOOTSTRAP_JS" <<'JSEOF'
console.log('Done');
JSEOF

  info "Creating tenant '${TENANT_ID}' and provider configs..."
  kubectl cp "$BOOTSTRAP_JS" "kclaw/${CREDROUTER_POD}:/tmp/bootstrap.mjs"
  kubectl exec -n kclaw "$CREDROUTER_POD" -- node /tmp/bootstrap.mjs
  kubectl exec -n kclaw "$CREDROUTER_POD" -- rm /tmp/bootstrap.mjs
  rm -f "$BOOTSTRAP_JS"

  k8s/credrouter/scripts/create-tenant-serviceaccount.sh "${TENANT_ID}" kclaw
  success "Tenant '${TENANT_ID}' bootstrapped"
}

# Bootstrap a tenant for every configured channel.
# slack-main also covers Slack DM groups — the orchestrator falls back to it
# for any DM group that doesn't have its own per-user tenant in CredRouter.
[[ -n "$SLACK_BOT_TOKEN" ]]    && bootstrap_tenant "slack-main"    "Slack Main"
[[ -n "$TELEGRAM_BOT_TOKEN" ]] && bootstrap_tenant "telegram-main" "Telegram Main"

success "CredRouter database bootstrapped"

# ── Phase 12: Admin UI bootstrap ─────────────────────────────────────────────
header "Phase 12 — Admin UI Bootstrap"

info "Waiting for Admin UI to be ready..."
kubectl wait --for=condition=ready pod -l app=kclaw-admin-ui -n kclaw --timeout=60s

kubectl port-forward -n kclaw svc/credrouter 8080:80 &>/dev/null &
PF_PID=$!
sleep 2

TEMP_PASSWORD=$(CREDROUTER_URL=http://127.0.0.1:8080 \
  CREDROUTER_ADMIN_TOKEN="$ADMIN_TOKEN" \
  npx tsx src/admin/cli.ts iam bootstrap "$ADMIN_EMAIL" --name "$ADMIN_DISPLAY_NAME" 2>&1 \
  | sed 's/\x1b\[[0-9;]*m//g' \
  | grep -oP 'Temporary Password:\s+\K\S+' || true)

kill $PF_PID 2>/dev/null || true
success "Admin user bootstrapped"

# ── Phase 13: Summary ─────────────────────────────────────────────────────────
header "Phase 13 — Summary"

NODE_IP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}')

SUMMARY_FILE="$REPO_ROOT/install-summary.txt"
cat > "$SUMMARY_FILE" <<SUMMARY
# KubeClaw Install Summary — $(date)
# ⚠️  KEEP THIS FILE SECURE. Add to .gitignore. DO NOT COMMIT.

NODE_IP=${NODE_IP}
NODE_HOSTNAME=${NODE_HOSTNAME}
LLM_PROVIDER=${LLM_PROVIDER}
$([[ "$LLM_PROVIDER" == "bedrock" ]]    && echo "AWS_REGION=${AWS_REGION}")
$([[ "$LLM_PROVIDER" == "openrouter" ]] && echo "OPENROUTER_MODEL=${OPENROUTER_MODEL}")

# Generated secrets — back these up safely
ENCRYPTION_KEY=${ENCRYPTION_KEY}
JWT_SECRET=${JWT_SECRET}
ADMIN_TOKEN=${ADMIN_TOKEN}
LITELLM_MASTER_KEY=${LITELLM_MASTER_KEY}
PG_PASSWORD=${PG_PASSWORD}
LITELLM_KEY_MAIN=${LITELLM_KEY_MAIN}

# Admin UI
ADMIN_UI_URL=http://${NODE_IP}
ADMIN_EMAIL=${ADMIN_EMAIL}
ADMIN_TEMP_PASSWORD=${TEMP_PASSWORD}

# LiteLLM (internal only — access via port-forward)
LITELLM_MASTER_KEY=${LITELLM_MASTER_KEY}
# kubectl port-forward svc/litellm-service 4000:4000 && open http://localhost:4000/ui

# Tenants
$([[ -n "$SLACK_BOT_TOKEN" ]] && echo "TENANT_SLACK=slack-main")
$([[ -n "$TELEGRAM_BOT_TOKEN" ]] && echo "TENANT_TELEGRAM=telegram-main")
SUMMARY

# Ensure install-summary.txt is in .gitignore
grep -qxF 'install-summary.txt' .gitignore 2>/dev/null || echo 'install-summary.txt' >> .gitignore

echo
echo -e "${GREEN}${BOLD}╔══════════════════════════════════════════════════════╗${RESET}"
echo -e "${GREEN}${BOLD}║     KubeClaw installed successfully! (${PLATFORM})     ║${RESET}"
echo -e "${GREEN}${BOLD}╚══════════════════════════════════════════════════════╝${RESET}"
echo
echo -e "  ${BOLD}Admin UI:${RESET}        http://${NODE_IP}"
echo -e "  ${BOLD}Admin email:${RESET}     ${ADMIN_EMAIL}"
echo -e "  ${BOLD}Temp password:${RESET}   ${TEMP_PASSWORD:-"(see install-summary.txt)"}"
echo -e "  ${BOLD}LiteLLM UI:${RESET}      kubectl port-forward svc/litellm-service 4000:4000 → http://localhost:4000/ui"
echo -e "  ${BOLD}Credentials:${RESET}     ${SUMMARY_FILE}"
echo
echo -e "${BOLD}${YELLOW}Slack Bot Setup:${RESET}"
echo "  1. https://api.slack.com/apps → Create New App → From Scratch"
echo "  2. Enable Socket Mode → generate xapp-... token"
echo "  3. OAuth & Permissions → add scopes:"
echo "       app_mentions:read, channels:history, channels:read, chat:write,"
echo "       files:read, groups:history, im:history, im:read, im:write,"
echo "       mpim:history, users:read"
echo "  4. Install to Workspace → copy xoxb-... token"
echo "  5. Event Subscriptions → enable + subscribe:"
echo "       app_mention, message.channels, message.groups, message.im, message.mpim"
echo "  6. Invite bot to your channel: /invite @KClaw"
echo "  7. Register channel: @${ASSISTANT_NAME} add group \"My Channel\""
echo
echo -e "  Full Slack setup guide: ${CYAN}specs/install-spec.md${RESET}"
echo

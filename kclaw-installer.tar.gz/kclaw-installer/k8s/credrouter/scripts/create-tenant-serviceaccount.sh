#!/bin/bash
# Script to create a ServiceAccount for a tenant
# Usage: ./create-tenant-serviceaccount.sh <tenant-name> [namespace]
#
# This creates a ServiceAccount with:
# - Pod label for tenant identification: kubeclaw.tenant=<tenant-name>
# - ServiceAccount annotation for tenant identification
# - Minimal RBAC permissions (none - agents don't need K8s API access)

set -e

TENANT_NAME="${1:-}"
NAMESPACE="${2:-kclaw}"

if [ -z "$TENANT_NAME" ]; then
  echo "Usage: $0 <tenant-name> [namespace]"
  echo ""
  echo "Example: $0 telegram-main kclaw"
  exit 1
fi

SA_NAME="kubeclaw-agent-${TENANT_NAME}"

echo "Creating ServiceAccount for tenant: $TENANT_NAME"
echo "ServiceAccount name: $SA_NAME"
echo "Namespace: $NAMESPACE"
echo ""

# Create ServiceAccount with annotation
kubectl apply -f - <<EOF
---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: $SA_NAME
  namespace: $NAMESPACE
  labels:
    app: kubeclaw-agent
    kubeclaw.tenant: $TENANT_NAME
  annotations:
    kubeclaw.tenant: $TENANT_NAME
    description: "ServiceAccount for KubeClaw agent pod - tenant: $TENANT_NAME"
EOF

echo "✅ ServiceAccount created: $SA_NAME"
echo ""
echo "Next steps:"
echo "  1. Deploy agent pod using this ServiceAccount"
echo "  2. Add pod label 'kubeclaw.tenant: $TENANT_NAME' to agent pods"
echo "  3. Ensure tenant '$TENANT_NAME' exists in CredRouter database"
echo ""
echo "Example pod spec:"
echo "---"
echo "apiVersion: v1"
echo "kind: Pod"
echo "metadata:"
echo "  name: kubeclaw-agent-$TENANT_NAME"
echo "  namespace: $NAMESPACE"
echo "  labels:"
echo "    app: kubeclaw-agent"
echo "    kubeclaw.tenant: $TENANT_NAME"
echo "spec:"
echo "  serviceAccountName: $SA_NAME"
echo "  containers:"
echo "    - name: agent"
echo "      image: kubeclaw/agent:latest"
echo "      env:"
echo "        - name: CREDROUTER_URL"
echo "          value: http://credrouter.kclaw.svc.cluster.local"
echo "        - name: TENANT_ID"
echo "          value: $TENANT_NAME"

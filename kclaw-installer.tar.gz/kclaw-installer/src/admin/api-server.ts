import http from 'http';
import { URL } from 'url';

import {
  logAdminAction,
  getAuditLogs,
  exportAuditLogsAsCsv,
} from '../admin-db.js';
import { logger } from '../logger.js';
import {
  getAllSessionsWithMetadata,
  markSessionStale,
  getRegisteredGroupByFolder,
} from '../db.js';
import {
  detectStaleSessions,
  getSessionInfo,
  resetSession,
  resetAllSessions,
  StaleSession,
  SessionInfo,
  ResetResult,
} from './services/session-manager.js';
import {
  buildJobManifest,
  VolumeMount,
  JobIdentity,
} from '../container-runner.js';
import { dispatchOneshotPod } from '../container-runner-persistent-http.js';
import { CONTAINER_IMAGE } from '../config.js';

export interface AdminApiConfig {
  port: number;
  host?: string;
  authToken?: string; // Optional Bearer token for authentication
  sendMessage?: (jid: string, text: string) => Promise<void>;
}

interface JsonResponse {
  success?: boolean;
  error?: string;
  data?: unknown;
  message?: string;
  [key: string]: unknown; // Allow additional properties
}

/**
 * Simple HTTP API server for admin operations.
 * Uses Node's built-in http module for zero additional dependencies.
 */
export class AdminApiServer {
  private server: http.Server | null = null;
  private config: AdminApiConfig;

  constructor(config: AdminApiConfig) {
    this.config = config;
  }

  start(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.server = http.createServer((req, res) => {
        this.handleRequest(req, res).catch((err) => {
          logger.error({ err, url: req.url }, 'Unhandled request error');
          this.sendJson(res, 500, { error: 'Internal server error' });
        });
      });

      this.server.on('error', reject);

      this.server.listen(
        this.config.port,
        this.config.host || '127.0.0.1',
        () => {
          logger.info(
            { port: this.config.port, host: this.config.host || '127.0.0.1' },
            'Admin API server started',
          );
          resolve();
        },
      );
    });
  }

  stop(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.server) {
        resolve();
        return;
      }

      this.server.close((err) => {
        if (err) {
          reject(err);
        } else {
          logger.info('Admin API server stopped');
          resolve();
        }
      });
    });
  }

  private async handleRequest(
    req: http.IncomingMessage,
    res: http.ServerResponse,
  ): Promise<void> {
    // CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
    res.setHeader(
      'Access-Control-Allow-Headers',
      'Content-Type, Authorization',
    );

    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return;
    }

    // Auth check (if token configured)
    if (this.config.authToken) {
      const authHeader = req.headers.authorization;
      if (!authHeader || authHeader !== `Bearer ${this.config.authToken}`) {
        this.sendJson(res, 401, { error: 'Unauthorized' });
        return;
      }
    }

    const url = new URL(req.url || '/', `http://${req.headers.host}`);
    const path = url.pathname;
    const method = req.method || 'GET';

    logger.debug({ method, path }, 'Admin API request');

    try {
      // Route to handlers
      if (path === '/admin/sessions' && method === 'GET') {
        await this.handleGetSessions(req, res, url);
      } else if (path.match(/^\/admin\/sessions\/[^/]+$/) && method === 'GET') {
        const groupFolder = path.split('/').pop()!;
        await this.handleGetSessionInfo(req, res, groupFolder);
      } else if (path === '/admin/sessions' && method === 'DELETE') {
        await this.handleResetAllSessions(req, res, url);
      } else if (
        path.match(/^\/admin\/sessions\/[^/]+$/) &&
        method === 'DELETE'
      ) {
        const groupFolder = path.split('/').pop()!;
        await this.handleResetSession(req, res, groupFolder, url);
      } else if (
        path.match(/^\/admin\/sessions\/[^/]+\/invalidate$/) &&
        method === 'POST'
      ) {
        const groupFolder = path.split('/')[3];
        await this.handleInvalidateSession(req, res, groupFolder);
      } else if (
        path.match(/^\/admin\/sessions\/[^/]+\/reload$/) &&
        method === 'POST'
      ) {
        const groupFolder = path.split('/')[3];
        await this.handleReloadSession(req, res, groupFolder);
      } else if (path === '/admin/sessions/detect-stale' && method === 'POST') {
        await this.handleDetectStale(req, res);
      } else if (
        path === '/admin/sessions/cleanup-stale' &&
        method === 'POST'
      ) {
        await this.handleCleanupStale(req, res, url);
      } else if (path === '/admin/audit/logs' && method === 'GET') {
        await this.handleGetAuditLogs(req, res, url);
      } else if (
        path.match(/^\/admin\/audit\/logs\/[^/]+$/) &&
        method === 'GET'
      ) {
        const id = path.split('/').pop()!;
        await this.handleGetAuditLog(req, res, id);
      } else if (path === '/admin/audit/export' && method === 'POST') {
        await this.handleExportAuditLogs(req, res);
      } else if (path === '/admin/jobs/dispatch' && method === 'POST') {
        await this.handleJobDispatch(req, res);
      } else if (path === '/admin/slack/lookup-user' && method === 'POST') {
        await this.handleSlackLookupUser(req, res);
      } else if (path === '/health' && method === 'GET') {
        await this.handleHealth(req, res);
      } else {
        this.sendJson(res, 404, { error: 'Not found' });
      }
    } catch (err) {
      logger.error({ err, path, method }, 'Request handler error');
      this.sendJson(res, 500, {
        error: err instanceof Error ? err.message : 'Internal server error',
      });
    }
  }

  // --- Session Management Handlers ---

  private async handleGetSessions(
    req: http.IncomingMessage,
    res: http.ServerResponse,
    url: URL,
  ): Promise<void> {
    const staleOnly = url.searchParams.get('stale') === 'true';

    const sessions = staleOnly
      ? detectStaleSessions()
      : getAllSessionsWithMetadata();

    this.sendJson(res, 200, {
      success: true,
      data: sessions,
      count: sessions.length,
    });
  }

  private async handleGetSessionInfo(
    req: http.IncomingMessage,
    res: http.ServerResponse,
    groupFolder: string,
  ): Promise<void> {
    const info = getSessionInfo(groupFolder);

    if (!info) {
      this.sendJson(res, 404, { error: 'Session not found' });
      return;
    }

    this.sendJson(res, 200, {
      success: true,
      data: info,
    });
  }

  private async handleResetSession(
    req: http.IncomingMessage,
    res: http.ServerResponse,
    groupFolder: string,
    url: URL,
  ): Promise<void> {
    const archive = url.searchParams.get('archive') === 'true';
    const adminUser = this.extractAdminUser(req);
    const adminIp = this.extractClientIp(req);

    const result = resetSession(groupFolder, { archive, adminUser, adminIp });

    if (result.success) {
      this.sendJson(res, 200, {
        success: true,
        data: result,
        message: 'Session reset successfully',
      });
    } else {
      this.sendJson(res, 500, {
        success: false,
        error: result.error,
      });
    }
  }

  private async handleResetAllSessions(
    req: http.IncomingMessage,
    res: http.ServerResponse,
    url: URL,
  ): Promise<void> {
    const staleOnly = url.searchParams.get('stale') === 'true';
    const archive = url.searchParams.get('archive') === 'true';
    const adminUser = this.extractAdminUser(req);
    const adminIp = this.extractClientIp(req);

    const results = resetAllSessions({
      staleOnly,
      archive,
      adminUser,
      adminIp,
    });

    const successCount = results.filter((r) => r.success).length;
    const failCount = results.filter((r) => !r.success).length;

    this.sendJson(res, 200, {
      success: true,
      data: results,
      summary: {
        total: results.length,
        success: successCount,
        failed: failCount,
      },
      message: `Reset ${successCount} sessions (${failCount} failed)`,
    });
  }

  private async handleInvalidateSession(
    req: http.IncomingMessage,
    res: http.ServerResponse,
    groupFolder: string,
  ): Promise<void> {
    const adminUser = this.extractAdminUser(req);
    const adminIp = this.extractClientIp(req);

    markSessionStale(groupFolder);

    logAdminAction({
      adminUser,
      adminIp,
      action: 'session_invalidate',
      resourceType: 'session',
      resourceId: groupFolder,
      status: 'success',
    });

    this.sendJson(res, 200, {
      success: true,
      message: 'Session marked as stale',
    });
  }

  private async handleReloadSession(
    _req: http.IncomingMessage,
    res: http.ServerResponse,
    groupFolder: string,
  ): Promise<void> {
    const safeName = groupFolder.replace(/[^a-zA-Z0-9-]/g, '-').toLowerCase();
    const podName = `kubeclaw-agent-${safeName}`;
    const namespace = process.env.K8S_NAMESPACE ?? 'kclaw';
    const podUrl = `http://${podName}.${namespace}.svc.cluster.local:3000/reload`;

    try {
      const response = await fetch(podUrl, {
        method: 'POST',
        signal: AbortSignal.timeout(10_000),
      });
      const data = (await response.json()) as Record<string, unknown>;
      if (!response.ok) {
        const errMsg = `Pod reload failed: ${data['error'] ?? response.status}`;
        logAdminAction({
          action: 'session_live_reload',
          resourceType: 'session',
          resourceId: groupFolder,
          status: 'error',
          errorMessage: errMsg,
        });
        this.sendJson(res, 502, { error: errMsg });
        return;
      }
      this.sendJson(res, 200, { success: true, ...data });
      logAdminAction({
        action: 'session_live_reload',
        resourceType: 'session',
        resourceId: groupFolder,
        status: 'success',
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      logAdminAction({
        action: 'session_live_reload',
        resourceType: 'session',
        resourceId: groupFolder,
        status: 'error',
        errorMessage: msg,
      });
      this.sendJson(res, 502, { error: `Could not reach pod: ${msg}` });
    }
  }

  private async handleDetectStale(
    req: http.IncomingMessage,
    res: http.ServerResponse,
  ): Promise<void> {
    const staleSessions = detectStaleSessions();

    this.sendJson(res, 200, {
      success: true,
      data: staleSessions,
      count: staleSessions.length,
    });
  }

  private async handleCleanupStale(
    req: http.IncomingMessage,
    res: http.ServerResponse,
    url: URL,
  ): Promise<void> {
    const archive = url.searchParams.get('archive') !== 'false'; // Default true
    const adminUser = this.extractAdminUser(req);
    const adminIp = this.extractClientIp(req);

    const results = resetAllSessions({
      staleOnly: true,
      archive,
      adminUser,
      adminIp,
    });

    const successCount = results.filter((r) => r.success).length;
    const failCount = results.filter((r) => !r.success).length;

    this.sendJson(res, 200, {
      success: true,
      data: results,
      summary: {
        total: results.length,
        success: successCount,
        failed: failCount,
      },
      message: `Cleaned up ${successCount} stale sessions (${failCount} failed)`,
    });
  }

  // --- Audit Log Handlers ---

  private async handleGetAuditLogs(
    req: http.IncomingMessage,
    res: http.ServerResponse,
    url: URL,
  ): Promise<void> {
    const filters = {
      action: url.searchParams.get('action') || undefined,
      resourceType: url.searchParams.get('resource_type') || undefined,
      resourceId: url.searchParams.get('resource_id') || undefined,
      since: url.searchParams.get('since') || undefined,
      until: url.searchParams.get('until') || undefined,
      status:
        (url.searchParams.get('status') as 'success' | 'error') || undefined,
      limit: url.searchParams.get('limit')
        ? parseInt(url.searchParams.get('limit')!, 10)
        : 100,
    };

    const logs = getAuditLogs(filters);

    this.sendJson(res, 200, {
      success: true,
      data: logs,
      count: logs.length,
    });
  }

  private async handleGetAuditLog(
    req: http.IncomingMessage,
    res: http.ServerResponse,
    id: string,
  ): Promise<void> {
    const logs = getAuditLogs({ limit: 1 });
    const log = logs.find((l) => l.id === id);

    if (!log) {
      this.sendJson(res, 404, { error: 'Audit log not found' });
      return;
    }

    this.sendJson(res, 200, {
      success: true,
      data: log,
    });
  }

  private async handleExportAuditLogs(
    req: http.IncomingMessage,
    res: http.ServerResponse,
  ): Promise<void> {
    const body = await this.readBody(req);
    const params = body ? JSON.parse(body) : {};

    const format = params.format || 'csv';
    const filters = {
      since: params.since,
      until: params.until,
      action: params.action,
      resourceType: params.resource_type,
      status: params.status,
    };

    if (format === 'csv') {
      const csv = exportAuditLogsAsCsv(filters);
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader(
        'Content-Disposition',
        'attachment; filename="audit-logs.csv"',
      );
      res.writeHead(200);
      res.end(csv);
    } else if (format === 'json') {
      const logs = getAuditLogs(filters);
      res.setHeader('Content-Type', 'application/json');
      res.setHeader(
        'Content-Disposition',
        'attachment; filename="audit-logs.json"',
      );
      res.writeHead(200);
      res.end(JSON.stringify(logs, null, 2));
    } else {
      this.sendJson(res, 400, { error: 'Invalid format. Use "csv" or "json"' });
    }
  }

  // --- Team Job Dispatch ---

  /**
   * Spawn a native K8s Job for a Class B team/persona agent.
   *
   * Called by CredRouter's run-now endpoint after it resolves the team PVC,
   * persona identity, and resource limits from its own DB.  The Orchestrator
   * holds the K8s RBAC (kubeclaw-job-manager) required to create Jobs, so
   * CredRouter delegates the actual dispatch here.
   *
   * POST /admin/jobs/dispatch
   * Body:
   *   jobName            string   — unique DNS-safe name for the K8s Job
   *   teamId?            string   — team identifier slug (for labels + env)
   *   teamPvcName?       string   — K8s PVC to mount at /workspace/shared
   *   personaId?         string   — persona UUID injected as KCLAW_PERSONA_ID
   *   personaInstructions? string — SOP fragment injected as KCLAW_PERSONA_INSTRUCTIONS
   */
  private async handleJobDispatch(
    req: http.IncomingMessage,
    res: http.ServerResponse,
  ): Promise<void> {
    const body = await this.readBody(req);
    if (!body) {
      this.sendJson(res, 400, { error: 'Request body is required' });
      return;
    }

    let payload: {
      jobName?: string;
      teamId?: string;
      teamPvcName?: string;
      personaId?: string;
      personaInstructions?: string;
      tenantIdentifier?: string;
      notifyJid?: string;
      prompt?: string;
    };
    try {
      payload = JSON.parse(body);
    } catch {
      this.sendJson(res, 400, { error: 'Invalid JSON body' });
      return;
    }

    if (!payload.jobName || typeof payload.jobName !== 'string') {
      this.sendJson(res, 400, { error: 'jobName is required' });
      return;
    }

    // Build mount list for the background job:
    //   /workspace/group — ephemeral emptyDir (no hostPath needed)
    //   /workspace/shared — Team PVC (present only when the team has one)
    const mounts: VolumeMount[] = [
      { containerPath: '/workspace/group', readonly: false, emptyDir: true },
    ];
    if (payload.teamPvcName) {
      mounts.push({
        containerPath: '/workspace/shared',
        readonly: false,
        pvcName: payload.teamPvcName,
      });
    }

    const identity: JobIdentity = {
      teamId: payload.teamId,
      personaId: payload.personaId,
      personaInstructions: payload.personaInstructions,
    };

    // Synthetic RegisteredGroup — used only for Job/Pod labels in buildJobManifest.
    // Background jobs have no "group folder" in the human-agent sense.
    const safeFolder = (payload.teamId ?? 'team-job')
      .toLowerCase()
      .replace(/[^a-z0-9-]/g, '-')
      .slice(0, 48);
    const group = {
      name: payload.teamId ?? 'team-job',
      folder: safeFolder,
      trigger: '',
      added_at: new Date().toISOString(),
    };

    // ContainerInput for the job manifest. prompt is empty for admin-triggered team
    // jobs (persona SOP drives execution), but user-level tasks supply a prompt.
    const input = {
      prompt: payload.prompt ?? '',
      groupFolder: safeFolder,
      chatJid: '',
      isMain: false,
      isScheduledTask: true,
    };

    const manifest = buildJobManifest(
      payload.jobName,
      mounts,
      input,
      group,
      identity,
    );

    // Override the image to use CONTAINER_IMAGE (standard agent image).
    // The persona's SOP is delivered via KCLAW_PERSONA_INSTRUCTIONS env var.
    if (manifest.spec?.template.spec?.containers?.[0]) {
      manifest.spec.template.spec.containers[0].image = CONTAINER_IMAGE;
    }

    // Stamp kubeclaw.tenant on the pod template so CredRouter's identity mapper
    // resolves the correct tenant credentials instead of falling back to 'default'.
    if (payload.tenantIdentifier) {
      const safeTenant = payload.tenantIdentifier
        .trim()
        .replace(/[^a-zA-Z0-9-_.]/g, '-')
        .replace(/^[-_.]+|[-_.]+$/g, '');
      if (safeTenant && manifest.spec?.template.metadata?.labels) {
        manifest.spec.template.metadata.labels['kubeclaw.tenant'] = safeTenant;
      }
    }

    // Resolve notifyJid early — needed for both success and error notifications.
    // notifyJid may be a platform_identifier (e.g. 'slack-dm-ryan') rather than
    // a raw chatJid.  Resolve via registered_groups.folder, trying both the
    // exact value and the underscore variant.
    let notifyJid = payload.notifyJid;
    if (notifyJid) {
      const byFolder =
        getRegisteredGroupByFolder(notifyJid) ??
        getRegisteredGroupByFolder(notifyJid.replace(/-/g, '_'));
      if (byFolder) notifyJid = byFolder.jid;
    }

    logger.info(
      {
        jobName: payload.jobName,
        teamId: payload.teamId,
        personaId: payload.personaId,
        teamPvcName: payload.teamPvcName ?? null,
        notifyJid: notifyJid ?? null,
      },
      'Dispatching persona job as oneshot pod',
    );

    // Respond 202 immediately — the pod runs entirely in the background.
    this.sendJson(res, 202, {
      success: true,
      jobName: payload.jobName,
      message: `Background job '${payload.jobName}' dispatched`,
    });

    // Run the oneshot pod in the background: create pod → POST prompt → get
    // result → notify → delete pod.
    const sendMessage = this.config.sendMessage;
    const jobName = payload.jobName;
    dispatchOneshotPod(
      jobName,
      manifest,
      payload.prompt ?? '',
      safeFolder,
      true, // isScheduledTask
      payload.tenantIdentifier,
      payload.teamId,
    )
      .then(async (output) => {
        if (notifyJid && sendMessage) {
          const icon = output.status === 'success' ? '✅' : '❌';
          const status = output.status === 'success' ? 'completed' : 'failed';
          const header = `${icon} Job *${jobName}* ${status}`;
          const body = output.result?.trim()
            ? `\n\n${output.result.trim()}`
            : '';
          await sendMessage(notifyJid, `${header}${body}`);
        }
      })
      .catch(async (err: Error) => {
        logger.error({ err, jobName }, 'Oneshot persona job failed');
        if (notifyJid && sendMessage) {
          await sendMessage(
            notifyJid,
            `❌ Job *${jobName}* failed: ${err.message}`,
          ).catch(() => {});
        }
      });
  }

  // --- Health Check ---

  private async handleHealth(
    req: http.IncomingMessage,
    res: http.ServerResponse,
  ): Promise<void> {
    this.sendJson(res, 200, {
      success: true,
      status: 'healthy',
      timestamp: new Date().toISOString(),
    });
  }

  // --- Helper Methods ---

  private async handleSlackLookupUser(
    req: http.IncomingMessage,
    res: http.ServerResponse,
  ): Promise<void> {
    const body = await this.readBody(req);
    let email: string | undefined;
    let tenantId: string | undefined;
    try {
      const parsed = JSON.parse(body);
      email = parsed.email;
      tenantId = parsed.tenantId;
    } catch {
      this.sendJson(res, 400, { error: 'Invalid JSON' });
      return;
    }

    if (!email || typeof email !== 'string') {
      this.sendJson(res, 400, { error: 'email is required' });
      return;
    }
    if (!tenantId || typeof tenantId !== 'string') {
      this.sendJson(res, 400, { error: 'tenantId is required' });
      return;
    }

    const botToken = process.env.SLACK_BOT_TOKEN;
    if (!botToken) {
      this.sendJson(res, 400, {
        error: 'Slack is not configured on this cluster',
      });
      return;
    }

    // Look up Slack user by email
    let slackUserId: string;
    try {
      const slackRes = await fetch(
        `https://slack.com/api/users.lookupByEmail?email=${encodeURIComponent(email)}`,
        { headers: { Authorization: `Bearer ${botToken}` } },
      );
      const slackData = (await slackRes.json()) as {
        ok: boolean;
        user?: { id: string };
        error?: string;
      };
      if (!slackData.ok || !slackData.user?.id) {
        this.sendJson(res, 404, {
          error: `Slack user not found: ${slackData.error ?? 'unknown'}`,
        });
        return;
      }
      slackUserId = slackData.user.id;
    } catch (err) {
      logger.error({ err }, 'Slack users.lookupByEmail failed');
      this.sendJson(res, 502, { error: 'Failed to reach Slack API' });
      return;
    }

    const platformIdentifier = `slack-dm-${slackUserId.toLowerCase()}`;

    // Create the platform_identifier mapping in CredRouter
    const credRouterUrl =
      process.env.CREDROUTER_URL ?? 'http://credrouter.kclaw.svc.cluster.local';
    const credRouterToken = process.env.CREDROUTER_ADMIN_TOKEN;
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (credRouterToken) headers['Authorization'] = `Bearer ${credRouterToken}`;

    try {
      const linkRes = await fetch(
        `${credRouterUrl}/admin/platform-identifiers`,
        {
          method: 'POST',
          headers,
          body: JSON.stringify({ platformIdentifier, tenantId }),
          signal: AbortSignal.timeout(10_000),
        },
      );
      if (!linkRes.ok) {
        const err = await linkRes.json().catch(() => ({}));
        logger.error(
          { status: linkRes.status, err },
          'CredRouter platform-identifier creation failed',
        );
        this.sendJson(res, 502, {
          error: 'Failed to create platform mapping in CredRouter',
        });
        return;
      }
    } catch (err) {
      logger.error(
        { err },
        'Failed to reach CredRouter for platform-identifier',
      );
      this.sendJson(res, 502, { error: 'Failed to reach CredRouter' });
      return;
    }

    logger.info(
      { email, slackUserId, platformIdentifier, tenantId },
      'Slack user linked to tenant',
    );
    this.sendJson(res, 200, { success: true, slackUserId, platformIdentifier });
  }

  private sendJson(
    res: http.ServerResponse,
    statusCode: number,
    data: JsonResponse,
  ): void {
    res.setHeader('Content-Type', 'application/json');
    res.writeHead(statusCode);
    res.end(JSON.stringify(data, null, 2));
  }

  private extractAdminUser(req: http.IncomingMessage): string {
    // Try to extract from Authorization header or other sources
    const authHeader = req.headers.authorization;
    if (authHeader?.startsWith('Bearer ')) {
      // Could decode JWT here if using JWT auth
      return 'admin'; // Placeholder
    }
    return 'system';
  }

  private extractClientIp(req: http.IncomingMessage): string {
    return (
      (req.headers['x-forwarded-for'] as string)?.split(',')[0] ||
      req.socket.remoteAddress ||
      'unknown'
    );
  }

  private readBody(req: http.IncomingMessage): Promise<string> {
    return new Promise((resolve, reject) => {
      let body = '';
      req.on('data', (chunk) => {
        body += chunk.toString();
      });
      req.on('end', () => resolve(body));
      req.on('error', reject);
    });
  }
}

/**
 * Start the admin API server with the given configuration.
 */
export async function startAdminApi(
  config: AdminApiConfig,
): Promise<AdminApiServer> {
  const server = new AdminApiServer(config);
  await server.start();
  return server;
}

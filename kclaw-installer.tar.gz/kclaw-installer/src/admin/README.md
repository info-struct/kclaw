# KubeClaw Admin API & CLI

Administrative interface for KubeClaw session management and audit logging.

## Components

### Admin API Server (`api-server.ts`)

HTTP REST API for administrative operations. Automatically starts with the main orchestrator.

**Configuration:**
- `ADMIN_API_PORT` (default: 3002)
- `ADMIN_API_HOST` (default: 127.0.0.1)
- `ADMIN_API_TOKEN` (optional Bearer token for authentication)

**Endpoints:**

#### Session Management
- `GET /admin/sessions` - List all sessions
  - Query params: `?stale=true` to filter stale sessions
- `GET /admin/sessions/:groupFolder` - Get detailed session info
- `DELETE /admin/sessions/:groupFolder` - Reset specific session
  - Query params: `?archive=true` to archive before reset
- `DELETE /admin/sessions` - Reset all sessions
  - Query params: `?stale=true&archive=true`
- `POST /admin/sessions/:groupFolder/invalidate` - Mark session as stale
- `POST /admin/sessions/detect-stale` - Detect sessions with outdated container versions
- `POST /admin/sessions/cleanup-stale` - Reset stale sessions with archiving

#### Audit Logs
- `GET /admin/audit/logs` - Query audit logs
  - Query params: `?action=<action>&since=<date>&status=<success|error>&limit=<n>`
- `GET /admin/audit/logs/:id` - Get specific audit log entry
- `POST /admin/audit/export` - Export logs as CSV/JSON
  - Body: `{ "format": "csv|json", "since": "date", "until": "date" }`

#### Health
- `GET /health` - Health check

### CLI Tool (`cli.ts`)

Command-line interface for admin operations. Uses the Admin API (orchestrator) and the CredRouter Admin API (tool credentials).

**Installation:**
```bash
# From project directory
npm link                    # Install globally
kclaw-admin health         # Test installation

# Or run directly
npm run admin -- health
npx tsx src/admin/cli.ts health
```

**Usage:**

```bash
# Session Management
kclaw-admin session list                           # List all sessions
kclaw-admin session list --stale                   # List only stale sessions
kclaw-admin session info main                      # Show detailed info for 'main' group
kclaw-admin session reset main --archive           # Reset with archiving
kclaw-admin session reset --all --archive          # Reset all with archiving
kclaw-admin session reset --stale --archive        # Reset only stale sessions
kclaw-admin session detect-stale                   # Detect stale sessions

# Audit Logs
kclaw-admin audit logs                             # Show recent logs
kclaw-admin audit logs --action session_reset      # Filter by action
kclaw-admin audit logs --since 2026-04-01          # Filter by date
kclaw-admin audit export --from 2026-04-01 --to 2026-04-12 --format csv

# Tool Credentials (talks to CredRouter — port-forward first)
kubectl port-forward -n openclaw svc/credrouter 8080:80 &
export CREDROUTER_URL=http://127.0.0.1:8080

kclaw-admin tool list <tenant-id>                                    # List configured tools
kclaw-admin tool set <tenant-id> <tool-name> key=value [key=value]  # Add / update a tool
kclaw-admin tool delete <tenant-id> <tool-name>                     # Remove a tool
kclaw-admin tool delete --force <tenant-id> <tool-name>             # Remove without confirmation

# Health Check
kclaw-admin health
```

**Environment Variables:**
- `ADMIN_API_PORT` - API port (default: 3002)
- `ADMIN_API_HOST` - API host (default: 127.0.0.1)
- `ADMIN_API_TOKEN` - Bearer token for orchestrator admin auth
- `CREDROUTER_URL` - CredRouter URL for tool commands (default: `http://127.0.0.1:8080`)
- `CREDROUTER_ADMIN_TOKEN` - Bearer token for CredRouter admin auth (optional)

---

## CredRouter Admin API (`src/credrouter/api/admin.ts`)

Tool credential management lives in the CredRouter, not in the orchestrator. These endpoints are served by CredRouter on its own port (default 3001 internally, port 80 via the K8s Service).

**Authentication:** Optional `CREDROUTER_ADMIN_TOKEN` Bearer token. If not set, unrestricted.

### Tool Credentials

- `GET /admin/tools/:tenantId` — List tool configs
  - Returns tool names and config key names. **Secret values are never returned.**
- `POST /admin/tools/:tenantId` — Upsert tool config
  - Body: `{ "toolName": "brave-search", "config": { "apiKey": "BSA-..." } }`
  - Automatically invalidates the tenant's credentials cache
- `DELETE /admin/tools/:tenantId/:toolName` — Remove a tool config
  - Automatically invalidates the credentials cache

**Example (via port-forward):**
```bash
kubectl port-forward -n openclaw svc/credrouter 8080:80 &

# List tools
curl http://127.0.0.1:8080/admin/tools/kubeclaw-orchestrator

# Add brave-search
curl -X POST http://127.0.0.1:8080/admin/tools/kubeclaw-orchestrator \
  -H "Content-Type: application/json" \
  -d '{"toolName":"brave-search","config":{"apiKey":"BSA-your-key"}}'

# Remove
curl -X DELETE http://127.0.0.1:8080/admin/tools/kubeclaw-orchestrator/brave-search
```

---

## Session Lifecycle

### Session States
- **active** - Normal operation
- **stale** - Container version mismatch detected
- **invalidated** - Marked for reset

### When to Reset Sessions

**Automatic triggers:**
- Container image update (version mismatch)
- Session age threshold exceeded

**Manual triggers:**
- Post-deployment cleanup
- User reports stale context
- Disk space cleanup

### Post-Deployment Workflow

```bash
# 1. Detect which sessions are outdated
kclaw-admin session detect-stale

# 2. Reset stale sessions and archive old transcripts
kclaw-admin session reset --stale --archive

# 3. Verify cleanup
kclaw-admin session list
```

### Session Storage

Sessions are stored in three locations:

1. **Database** (`store/messages.db` → `sessions` table)
   - Maps `group_folder` → `session_id`
   - Tracks metadata (container version, timestamps, status)

2. **In-Memory** (orchestrator runtime)
   - Fast lookup cache
   - Cleared on restart

3. **Filesystem** (`groups/{group-folder}/transcript-*.jsonl`)
   - Full conversation history
   - Can be archived before reset

When a session is reset:
- Database entry is deleted
- In-memory cache is cleared
- Transcript files are optionally archived to `data/sessions-archive/`

## Audit Logging

All administrative actions are logged for compliance and security:

**Logged Actions:**
- `session_reset` - Single session reset
- `session_reset_bulk` - Bulk session reset
- `session_invalidate` - Session marked as stale

**Log Fields:**
- `timestamp` - When the action occurred
- `admin_user` - Who performed it (from Bearer token or 'system')
- `admin_ip` - Source IP address
- `action` - Action type
- `resource_type` - 'session', 'tenant', etc.
- `resource_id` - Group folder or tenant ID
- `details` - JSON metadata (session ID, archive path, etc.)
- `status` - 'success' or 'error'
- `error_message` - Error details if failed

**Querying Logs:**
```bash
# Recent activity
kclaw-admin audit logs --limit 20

# Specific action
kclaw-admin audit logs --action session_reset

# Date range
kclaw-admin audit logs --since 2026-04-01 --until 2026-04-12

# Export for compliance
kclaw-admin audit export --from 2026-01-01 --to 2026-04-12 --format csv > audit-q1.csv
```

## Security

### Authentication

The Admin API supports optional Bearer token authentication:

```bash
# Set token in environment
export ADMIN_API_TOKEN="your-secret-token-here"

# API will require Authorization header
curl -H "Authorization: Bearer your-secret-token-here" http://localhost:3002/admin/sessions
```

Without a token, the API is accessible only on localhost (127.0.0.1).

### Network Binding

By default, the API binds to `127.0.0.1:3002` (localhost only).

To expose on a network interface:
```bash
export ADMIN_API_HOST="0.0.0.0"  # Listen on all interfaces
export ADMIN_API_PORT="3002"      # Custom port
export ADMIN_API_TOKEN="..."      # REQUIRED when exposing to network
```

**⚠️ Warning:** Never expose the Admin API to the public internet without authentication!

## Development

### Testing the API

```bash
# Start orchestrator with Admin API
npm run dev

# In another terminal, test endpoints
curl http://localhost:3002/health
curl http://localhost:3002/admin/sessions
curl -X POST http://localhost:3002/admin/sessions/detect-stale

# Or use the CLI
npm run admin -- session list
npm run admin -- health
```

### Running Tests

```bash
# Start test server
npx tsx tests/admin-api-test.ts

# Test with curl
curl http://localhost:3002/health
curl http://localhost:3002/admin/sessions
```

## Troubleshooting

### CLI can't connect to API

```
Error: Cannot connect to Admin API at http://127.0.0.1:3002. Is the KClaw orchestrator running?
```

**Solution:** Start the orchestrator first:
```bash
npm run dev
```

### API returns 401 Unauthorized

**Solution:** Check if `ADMIN_API_TOKEN` is set and matches:
```bash
echo $ADMIN_API_TOKEN
```

### Session reset failed

Check the audit logs for details:
```bash
kclaw-admin audit logs --action session_reset --status error
```

## Future Enhancements (Spec Phase 3-5)

- **Tenant Management** - Multi-tenant onboarding and lifecycle
- **Dispatch Engine** - Proactive message sending across channels
- **Health Monitoring** - Channel connectivity and agent pod status
- **Web Dashboard** - React UI for visual session management
- **Metrics** - Prometheus-compatible metrics endpoint

See [specs/admin-api-cli-spec.md](../../specs/admin-api-cli-spec.md) for the full roadmap.

## Implemented — Tool Credentials

✅ `kclaw-admin tool list/set/delete` — manage third-party API keys in CredRouter
✅ CredRouter Admin API: `GET/POST/DELETE /admin/tools/:tenantId`
See [specs/TOOLS-CREDDENTIALS_SPEC.md](../../specs/TOOLS-CREDDENTIALS_SPEC.md) for details.

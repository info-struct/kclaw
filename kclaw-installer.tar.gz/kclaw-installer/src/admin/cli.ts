#!/usr/bin/env node

/**
 * kclaw-admin CLI tool
 *
 * Provides command-line interface for KClaw administrative operations.
 * Communicates with the Admin API server running on localhost.
 *
 * Usage:
 *   kclaw-admin session list [--stale]
 *   kclaw-admin session info <group-folder>
 *   kclaw-admin session reset <group-folder> [--archive]
 *   kclaw-admin session reset --all [--archive] [--stale]
 *   kclaw-admin session detect-stale
 *   kclaw-admin audit logs [--action <action>] [--since <date>]
 *   kclaw-admin audit export --from <date> --to <date> --format <csv|json>
 *   kclaw-admin health
 */

import { readFileSync } from 'fs';
import { join } from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

// ANSI color codes for terminal output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  dim: '\x1b[2m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  gray: '\x1b[90m',
};

interface CliConfig {
  apiUrl: string;
  apiToken?: string;
  credRouterUrl: string;
  credRouterToken?: string;
}

function loadConfig(): CliConfig {
  // Load from environment or default
  const port = process.env.ADMIN_API_PORT || '3002';
  const host = process.env.ADMIN_API_HOST || '127.0.0.1';
  const apiToken = process.env.ADMIN_API_TOKEN;

  // CredRouter admin API — port-forward svc/credrouter to reach from outside cluster
  const credRouterUrl = process.env.CREDROUTER_URL || 'http://127.0.0.1:8080';
  const credRouterToken = process.env.CREDROUTER_ADMIN_TOKEN;

  return {
    apiUrl: `http://${host}:${port}`,
    apiToken,
    credRouterUrl,
    credRouterToken,
  };
}

async function apiRequest(
  config: CliConfig,
  path: string,
  options: {
    method?: string;
    body?: unknown;
    query?: Record<string, string>;
  } = {},
): Promise<unknown> {
  const method = options.method || 'GET';
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (config.apiToken) {
    headers['Authorization'] = `Bearer ${config.apiToken}`;
  }

  // Build URL with query params
  let url = `${config.apiUrl}${path}`;
  if (options.query) {
    const params = new URLSearchParams(options.query);
    url += `?${params.toString()}`;
  }

  const fetchOptions: RequestInit = {
    method,
    headers,
  };

  if (options.body) {
    fetchOptions.body = JSON.stringify(options.body);
  }

  try {
    const response = await fetch(url, fetchOptions);
    const contentType = response.headers.get('content-type');

    if (contentType?.includes('application/json')) {
      const data = (await response.json()) as {
        error?: string;
        [key: string]: unknown;
      };
      if (!response.ok) {
        throw new Error(
          data.error || `HTTP ${response.status}: ${response.statusText}`,
        );
      }
      return data;
    } else if (
      contentType?.includes('text/csv') ||
      contentType?.includes('text/plain')
    ) {
      const text = await response.text();
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      return text;
    } else {
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      return await response.text();
    }
  } catch (err) {
    if (err instanceof Error) {
      if (err.message.includes('ECONNREFUSED')) {
        throw new Error(
          `Cannot connect to Admin API at ${url}. Is the KClaw orchestrator running?`,
        );
      }
      throw err;
    }
    throw new Error(String(err));
  }
}

async function credRouterRequest(
  config: CliConfig,
  path: string,
  options: { method?: string; body?: unknown } = {},
): Promise<unknown> {
  const method = options.method || 'GET';
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (config.credRouterToken) {
    headers['Authorization'] = `Bearer ${config.credRouterToken}`;
  }

  const url = `${config.credRouterUrl}${path}`;
  const fetchOptions: RequestInit = { method, headers };
  if (options.body) {
    fetchOptions.body = JSON.stringify(options.body);
  }

  try {
    const response = await fetch(url, fetchOptions);
    const data = (await response.json()) as {
      error?: string;
      [key: string]: unknown;
    };
    if (!response.ok) {
      throw new Error(
        data.error || `HTTP ${response.status}: ${response.statusText}`,
      );
    }
    return data;
  } catch (err) {
    if (err instanceof Error) {
      if (err.message.includes('ECONNREFUSED')) {
        throw new Error(
          `Cannot connect to CredRouter at ${url}.\n  Run: kubectl port-forward -n kclaw svc/credrouter 8080:80`,
        );
      }
      throw err;
    }
    throw new Error(String(err));
  }
}

// --- IAM Command Handlers ---

async function iamBootstrap(config: CliConfig, args: string[]): Promise<void> {
  let email = args.find((a) => !a.startsWith('-'));

  if (!email) {
    const readline = await import('readline');
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
    });
    email = await new Promise<string>((resolve) => {
      rl.question(
        `${colors.blue}?${colors.reset} Global Admin email: `,
        (answer) => {
          rl.close();
          resolve(answer.trim());
        },
      );
    });
  }

  if (!email) {
    printError('Email is required');
    process.exit(1);
  }

  const nameFlag = args.indexOf('--name');
  const name = nameFlag !== -1 ? args[nameFlag + 1] : undefined;

  printInfo('Creating Global Admin...');

  const response = (await credRouterRequest(config, '/admin/iam/bootstrap', {
    method: 'POST',
    body: { email, ...(name && { name }) },
  })) as {
    success: boolean;
    message: string;
    tempPassword: string;
    user: { id: string; email: string; role: string };
  };

  printSuccess(response.message);
  console.log();
  console.log(
    `  ${colors.bright}Email:${colors.reset}             ${response.user.email}`,
  );
  console.log(
    `  ${colors.bright}Role:${colors.reset}              ${response.user.role}`,
  );
  console.log(
    `  ${colors.bright}Temporary Password:${colors.reset} ${colors.yellow}${response.tempPassword}${colors.reset}`,
  );
  console.log();
  printInfo('The user must change this password on first login.');
  console.log();
}

async function iamResetPassword(
  config: CliConfig,
  args: string[],
): Promise<void> {
  let email = args.find((a) => !a.startsWith('-'));

  if (!email) {
    printError('Missing required argument: <email>');
    console.log('Usage: kclaw-admin iam reset-password <email>');
    process.exit(1);
  }

  const confirmed = await confirm(`Reset password for '${email}'?`);
  if (!confirmed) {
    printInfo('Aborted');
    return;
  }

  const response = (await credRouterRequest(
    config,
    '/admin/iam/reset-password',
    {
      method: 'POST',
      body: { email },
    },
  )) as {
    success: boolean;
    message: string;
    tempPassword: string;
    user: { id: string; email: string };
  };

  printSuccess(response.message);
  console.log();
  console.log(
    `  ${colors.bright}Email:${colors.reset}              ${response.user.email}`,
  );
  console.log(
    `  ${colors.bright}Temporary Password:${colors.reset}  ${colors.yellow}${response.tempPassword}${colors.reset}`,
  );
  console.log();
}

async function iamListUsers(config: CliConfig): Promise<void> {
  const response = (await credRouterRequest(config, '/admin/iam/users')) as {
    data: Array<{
      id: string;
      email: string;
      name: string | null;
      role: string;
      tenantId: string | null;
      mustChangePassword: boolean;
      createdAt: number;
    }>;
  };

  if (response.data.length === 0) {
    printInfo(
      'No users found. Run "kclaw-admin iam bootstrap" to create the first admin.',
    );
    return;
  }

  console.log(
    `\n${colors.bright}IAM Users${colors.reset} (${response.data.length} total)\n`,
  );
  console.log(
    `${'Email'.padEnd(35)} ${'Role'.padEnd(12)} ${'Tenant'.padEnd(20)} ${'Must Change Pwd'}`,
  );
  console.log('-'.repeat(90));

  for (const user of response.data) {
    const mustChange = user.mustChangePassword
      ? `${colors.yellow}yes${colors.reset}`
      : `${colors.green}no${colors.reset}`;
    console.log(
      `${user.email.padEnd(35)} ${user.role.padEnd(12)} ${(user.tenantId ?? colors.gray + 'none' + colors.reset).padEnd(20)} ${mustChange}`,
    );
  }
  console.log();
}

function iamSsoSetup(): void {
  printInfo('SSO setup (SAML/OIDC) is not yet implemented.');
  printInfo(
    'Track progress at: https://github.com/gryanfawcett/kubeclaw/issues',
  );
  console.log();
}

// --- Tool Command Handlers ---

async function toolList(config: CliConfig, args: string[]): Promise<void> {
  const tenantId = args.find((a) => !a.startsWith('-'));
  if (!tenantId) {
    printError('Missing required argument: <tenant-id>');
    console.log('Usage: kclaw-admin tool list <tenant-id>');
    process.exit(1);
  }

  const response = (await credRouterRequest(
    config,
    `/admin/tools/${tenantId}`,
  )) as {
    data: Array<{
      toolName: string;
      configKeys: string[];
      createdAt: string;
      updatedAt: string;
    }>;
    count: number;
  };

  if (response.count === 0) {
    printInfo(`No tool configs found for tenant '${tenantId}'`);
    return;
  }

  console.log(
    `\n${colors.bright}Tool Configs${colors.reset} for ${colors.cyan}${tenantId}${colors.reset} (${response.count} total)\n`,
  );
  console.log(
    `${'Tool Name'.padEnd(20)} ${'Config Keys'.padEnd(30)} ${'Updated'}`,
  );
  console.log('-'.repeat(75));

  for (const tool of response.data) {
    console.log(
      `${colors.bright}${tool.toolName.padEnd(20)}${colors.reset} ${colors.dim}${tool.configKeys.join(', ').padEnd(30)}${colors.reset} ${formatDate(tool.updatedAt)}`,
    );
  }
  console.log();
}

async function toolSet(config: CliConfig, args: string[]): Promise<void> {
  const tenantId = args[0];
  const toolName = args[1];
  const kvPairs = args.slice(2);

  if (!tenantId || !toolName) {
    printError('Missing required arguments');
    console.log(
      'Usage: kclaw-admin tool set <tenant-id> <tool-name> <key=value> ...',
    );
    console.log(
      'Example: kclaw-admin tool set telegram-main brave-search apiKey=BSA-xxx',
    );
    process.exit(1);
  }

  if (kvPairs.length === 0) {
    printError('Provide at least one key=value config pair');
    console.log(
      'Example: kclaw-admin tool set telegram-main brave-search apiKey=BSA-xxx',
    );
    process.exit(1);
  }

  // Parse key=value pairs into config object
  const toolConfig: Record<string, string> = {};
  for (const pair of kvPairs) {
    const eqIdx = pair.indexOf('=');
    if (eqIdx === -1) {
      printError(`Invalid key=value pair: '${pair}'`);
      process.exit(1);
    }
    const key = pair.slice(0, eqIdx);
    const value = pair.slice(eqIdx + 1);
    if (!key) {
      printError(`Empty key in pair: '${pair}'`);
      process.exit(1);
    }
    toolConfig[key] = value;
  }

  const response = (await credRouterRequest(
    config,
    `/admin/tools/${tenantId}`,
    { method: 'POST', body: { toolName, config: toolConfig } },
  )) as { message: string; note: string };

  printSuccess(response.message);
  printInfo(response.note);
  console.log();
  printInfo(`Run the following to apply immediately:`);
  console.log(
    `  kubectl delete pod -n kclaw -l kubeclaw.group=${tenantId.replace(/_/g, '-')} 2>/dev/null || echo "No pod running for this tenant"`,
  );
  console.log();
}

async function toolDelete(config: CliConfig, args: string[]): Promise<void> {
  const positional = args.filter((a) => !a.startsWith('-'));
  const tenantId = positional[0];
  const toolName = positional[1];
  const force = args.includes('--force');

  if (!tenantId || !toolName) {
    printError('Missing required arguments');
    console.log('Usage: kclaw-admin tool delete <tenant-id> <tool-name>');
    process.exit(1);
  }

  if (!force) {
    const confirmed = await confirm(
      `Remove tool '${toolName}' from tenant '${tenantId}'?`,
    );
    if (!confirmed) {
      printInfo('Aborted');
      return;
    }
  }

  const response = (await credRouterRequest(
    config,
    `/admin/tools/${tenantId}/${toolName}`,
    { method: 'DELETE' },
  )) as { message: string; note: string };

  printSuccess(response.message);
  printInfo(response.note);
  console.log();
}

function formatDate(dateStr: string | null): string {
  if (!dateStr) return colors.gray + 'never' + colors.reset;
  const date = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return colors.green + 'just now' + colors.reset;
  if (diffMins < 60) return colors.green + `${diffMins}m ago` + colors.reset;
  if (diffHours < 24) return colors.yellow + `${diffHours}h ago` + colors.reset;
  if (diffDays < 7) return colors.yellow + `${diffDays}d ago` + colors.reset;
  return colors.gray + date.toISOString().split('T')[0] + colors.reset;
}

function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${(bytes / Math.pow(k, i)).toFixed(1)} ${sizes[i]}`;
}

function printError(message: string): void {
  console.error(`${colors.red}✗${colors.reset} ${message}`);
}

function printSuccess(message: string): void {
  console.log(`${colors.green}✓${colors.reset} ${message}`);
}

function printInfo(message: string): void {
  console.log(`${colors.blue}ℹ${colors.reset} ${message}`);
}

function printWarning(message: string): void {
  console.log(`${colors.yellow}⚠${colors.reset} ${message}`);
}

async function confirm(message: string): Promise<boolean> {
  const readline = await import('readline');
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  return new Promise((resolve) => {
    rl.question(
      `${colors.yellow}?${colors.reset} ${message} (y/N): `,
      (answer) => {
        rl.close();
        resolve(answer.toLowerCase() === 'y' || answer.toLowerCase() === 'yes');
      },
    );
  });
}

// --- Command Handlers ---

async function sessionList(config: CliConfig, args: string[]): Promise<void> {
  const stale = args.includes('--stale');
  const query: Record<string, string> = {};
  if (stale) query.stale = 'true';

  const response = (await apiRequest(config, '/admin/sessions', {
    query,
  })) as {
    data: Array<{
      groupFolder: string;
      sessionId: string;
      containerVersion: string | null;
      createdAt: string | null;
      lastUsedAt: string | null;
      status: string | null;
    }>;
  };

  if (response.data.length === 0) {
    printInfo(stale ? 'No stale sessions found' : 'No sessions found');
    return;
  }

  console.log(
    `\n${colors.bright}${stale ? 'Stale Sessions' : 'Sessions'}${colors.reset} (${response.data.length} total)\n`,
  );
  console.log(
    `${'Group Folder'.padEnd(30)} ${'Status'.padEnd(12)} ${'Version'.padEnd(20)} ${'Last Used'}`,
  );
  console.log('-'.repeat(100));

  for (const session of response.data) {
    const statusColor =
      session.status === 'active'
        ? colors.green
        : session.status === 'stale'
          ? colors.yellow
          : colors.red;
    const status = `${statusColor}${(session.status || 'unknown').padEnd(12)}${colors.reset}`;
    const version = (
      session.containerVersion || colors.gray + 'unknown' + colors.reset
    ).padEnd(20);
    const lastUsed = formatDate(session.lastUsedAt);

    console.log(
      `${session.groupFolder.padEnd(30)} ${status} ${version} ${lastUsed}`,
    );
  }
  console.log();
}

async function sessionInfo(config: CliConfig, args: string[]): Promise<void> {
  if (args.length === 0) {
    printError('Missing required argument: <group-folder>');
    console.log('Usage: kclaw-admin session info <group-folder>');
    process.exit(1);
  }

  const groupFolder = args[0];
  const response = (await apiRequest(
    config,
    `/admin/sessions/${groupFolder}`,
  )) as {
    data: {
      groupFolder: string;
      sessionId: string;
      containerVersion: string | null;
      createdAt: string | null;
      lastUsedAt: string | null;
      status: string | null;
      transcriptSize: number;
      transcriptExists: boolean;
      age: number;
    };
  };

  const session = response.data;
  const ageHours = Math.floor(session.age / 3600000);
  const ageDays = Math.floor(ageHours / 24);

  console.log(
    `\n${colors.bright}Session: ${session.groupFolder}${colors.reset}\n`,
  );
  console.log(`  Session ID:        ${session.sessionId}`);
  console.log(
    `  Status:            ${session.status === 'active' ? colors.green : colors.yellow}${session.status}${colors.reset}`,
  );
  console.log(
    `  Container Version: ${session.containerVersion || colors.gray + 'unknown' + colors.reset}`,
  );
  console.log(
    `  Created:           ${formatDate(session.createdAt)} (${ageDays}d ${ageHours % 24}h ago)`,
  );
  console.log(`  Last Used:         ${formatDate(session.lastUsedAt)}`);
  console.log(
    `  Transcript:        ${session.transcriptExists ? colors.green + formatBytes(session.transcriptSize) + colors.reset : colors.gray + 'not found' + colors.reset}`,
  );
  console.log();
}

async function sessionReset(config: CliConfig, args: string[]): Promise<void> {
  const archive = args.includes('--archive');
  const all = args.includes('--all');
  const stale = args.includes('--stale');
  const force = args.includes('--force');

  if (all) {
    // Reset all sessions
    const what = stale ? 'all stale sessions' : 'ALL sessions';
    if (!force) {
      const confirmed = await confirm(`This will reset ${what}. Continue?`);
      if (!confirmed) {
        printInfo('Aborted');
        return;
      }
    }

    const query: Record<string, string> = {};
    if (stale) query.stale = 'true';
    if (archive) query.archive = 'true';

    printInfo(`Resetting ${what}...`);
    const response = (await apiRequest(config, '/admin/sessions', {
      method: 'DELETE',
      query,
    })) as {
      summary: { total: number; success: number; failed: number };
      message: string;
    };

    if (response.summary.failed > 0) {
      printWarning(response.message);
    } else {
      printSuccess(response.message);
    }
  } else {
    // Reset single session
    const groupFolder = args.find((arg) => !arg.startsWith('--'));
    if (!groupFolder) {
      printError('Missing required argument: <group-folder>');
      console.log(
        'Usage: kclaw-admin session reset <group-folder> [--archive]',
      );
      console.log(
        '   or: kclaw-admin session reset --all [--archive] [--stale] [--force]',
      );
      process.exit(1);
    }

    if (!force) {
      const confirmed = await confirm(
        `This will reset session for ${groupFolder}${archive ? ' (with archiving)' : ''}. Continue?`,
      );
      if (!confirmed) {
        printInfo('Aborted');
        return;
      }
    }

    const query: Record<string, string> = {};
    if (archive) query.archive = 'true';

    const response = (await apiRequest(
      config,
      `/admin/sessions/${groupFolder}`,
      {
        method: 'DELETE',
        query,
      },
    )) as {
      message: string;
      data: { archivePath?: string };
    };

    printSuccess(response.message);
    if (response.data.archivePath) {
      printInfo(`Archived to: ${response.data.archivePath}`);
    }
  }
}

async function sessionDetectStale(config: CliConfig): Promise<void> {
  const response = (await apiRequest(config, '/admin/sessions/detect-stale', {
    method: 'POST',
  })) as {
    data: Array<{
      groupFolder: string;
      currentVersion: string;
      containerVersion: string | null;
    }>;
    count: number;
  };

  if (response.count === 0) {
    printSuccess('No stale sessions detected');
    return;
  }

  printWarning(`Found ${response.count} stale session(s):\n`);
  for (const session of response.data) {
    console.log(
      `  ${colors.yellow}•${colors.reset} ${session.groupFolder} (${session.containerVersion || 'unknown'} → ${session.currentVersion})`,
    );
  }
  console.log();
  printInfo('Run "kclaw-admin session reset --stale --archive" to clean up');
}

async function auditLogs(config: CliConfig, args: string[]): Promise<void> {
  const query: Record<string, string> = {};

  // Parse flags
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--action' && args[i + 1]) {
      query.action = args[i + 1];
      i++;
    } else if (args[i] === '--since' && args[i + 1]) {
      query.since = args[i + 1];
      i++;
    } else if (args[i] === '--until' && args[i + 1]) {
      query.until = args[i + 1];
      i++;
    } else if (args[i] === '--status' && args[i + 1]) {
      query.status = args[i + 1];
      i++;
    } else if (args[i] === '--limit' && args[i + 1]) {
      query.limit = args[i + 1];
      i++;
    }
  }

  const response = (await apiRequest(config, '/admin/audit/logs', {
    query,
  })) as {
    data: Array<{
      id: string;
      timestamp: string;
      adminUser: string;
      action: string;
      resourceType: string;
      resourceId: string | null;
      status: string;
    }>;
    count: number;
  };

  if (response.count === 0) {
    printInfo('No audit logs found');
    return;
  }

  console.log(
    `\n${colors.bright}Audit Logs${colors.reset} (${response.count} entries)\n`,
  );
  console.log(
    `${'Timestamp'.padEnd(25)} ${'User'.padEnd(15)} ${'Action'.padEnd(25)} ${'Resource'.padEnd(20)} ${'Status'}`,
  );
  console.log('-'.repeat(110));

  for (const log of response.data) {
    const statusColor = log.status === 'success' ? colors.green : colors.red;
    const timestamp = new Date(log.timestamp)
      .toISOString()
      .replace('T', ' ')
      .slice(0, 19);
    const resource = `${log.resourceType}:${log.resourceId || '-'}`;

    console.log(
      `${timestamp.padEnd(25)} ${log.adminUser.padEnd(15)} ${log.action.padEnd(25)} ${resource.padEnd(20)} ${statusColor}${log.status}${colors.reset}`,
    );
  }
  console.log();
}

async function auditExport(config: CliConfig, args: string[]): Promise<void> {
  const params: Record<string, string> = {};

  // Parse flags
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--from' && args[i + 1]) {
      params.since = args[i + 1];
      i++;
    } else if (args[i] === '--to' && args[i + 1]) {
      params.until = args[i + 1];
      i++;
    } else if (args[i] === '--format' && args[i + 1]) {
      params.format = args[i + 1];
      i++;
    } else if (args[i] === '--action' && args[i + 1]) {
      params.action = args[i + 1];
      i++;
    }
  }

  if (!params.format) {
    params.format = 'csv';
  }

  if (!params.since || !params.until) {
    printError('Missing required arguments: --from <date> --to <date>');
    console.log(
      'Usage: kclaw-admin audit export --from <date> --to <date> --format <csv|json>',
    );
    process.exit(1);
  }

  const response = await apiRequest(config, '/admin/audit/export', {
    method: 'POST',
    body: params,
  });

  console.log(response);
}

async function health(config: CliConfig): Promise<void> {
  const response = (await apiRequest(config, '/health')) as {
    status: string;
    timestamp: string;
  };

  if (response.status === 'healthy') {
    printSuccess('Admin API is healthy');
    console.log(`  Timestamp: ${response.timestamp}`);
  } else {
    printError('Admin API is unhealthy');
  }
}

// --- Main CLI Router ---

async function main(): Promise<void> {
  const args = process.argv.slice(2);

  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
    printHelp();
    return;
  }

  const config = loadConfig();
  const [command, subcommand, ...rest] = args;

  try {
    if (command === 'session' || command === 's') {
      switch (subcommand) {
        case 'list':
        case 'ls':
          await sessionList(config, rest);
          break;
        case 'info':
          await sessionInfo(config, rest);
          break;
        case 'reset':
          await sessionReset(config, rest);
          break;
        case 'detect-stale':
          await sessionDetectStale(config);
          break;
        default:
          printError(`Unknown session subcommand: ${subcommand}`);
          printHelp();
          process.exit(1);
      }
    } else if (command === 'audit' || command === 'a') {
      switch (subcommand) {
        case 'logs':
          await auditLogs(config, rest);
          break;
        case 'export':
          await auditExport(config, rest);
          break;
        default:
          printError(`Unknown audit subcommand: ${subcommand}`);
          printHelp();
          process.exit(1);
      }
    } else if (command === 'tool' || command === 't') {
      switch (subcommand) {
        case 'list':
        case 'ls':
          await toolList(config, rest);
          break;
        case 'set':
          await toolSet(config, rest);
          break;
        case 'delete':
        case 'rm':
          await toolDelete(config, rest);
          break;
        default:
          printError(`Unknown tool subcommand: ${subcommand}`);
          printHelp();
          process.exit(1);
      }
    } else if (command === 'iam' || command === 'i') {
      switch (subcommand) {
        case 'bootstrap':
          await iamBootstrap(config, rest);
          break;
        case 'reset-password':
          await iamResetPassword(config, rest);
          break;
        case 'list':
        case 'ls':
          await iamListUsers(config);
          break;
        case 'sso-setup':
          iamSsoSetup();
          break;
        default:
          printError(`Unknown iam subcommand: ${subcommand}`);
          printHelp();
          process.exit(1);
      }
    } else if (command === 'health' || command === 'h') {
      await health(config);
    } else {
      printError(`Unknown command: ${command}`);
      printHelp();
      process.exit(1);
    }
  } catch (err) {
    if (err instanceof Error) {
      printError(err.message);
    } else {
      printError(String(err));
    }
    process.exit(1);
  }
}

function printHelp(): void {
  console.log(`
${colors.bright}kclaw-admin${colors.reset} - KClaw Admin CLI

${colors.bright}Usage:${colors.reset}
  kclaw-admin <command> <subcommand> [options]

${colors.bright}Session Management:${colors.reset}
  session list [--stale]                          List all sessions (or only stale)
  session info <group-folder>                     Show detailed session info
  session reset <group-folder> [--archive]        Reset specific session
  session reset --all [--archive] [--stale]       Reset all (or stale) sessions
  session detect-stale                            Detect sessions with outdated versions

${colors.bright}Audit Logs:${colors.reset}
  audit logs [--action <action>] [--since <date>] Query audit logs
  audit export --from <date> --to <date>          Export audit logs as CSV/JSON
               [--format csv|json]

${colors.bright}IAM:${colors.reset} (talks to CredRouter — port-forward first)
  iam bootstrap [<email>] [--name <name>]          Create the first Global Admin
  iam reset-password <email>                       Generate a new temporary password
  iam list                                         List all IAM users
  iam sso-setup                                    Configure SAML/OIDC (coming soon)

${colors.bright}Tool Credentials:${colors.reset} (talks to CredRouter — port-forward first)
  tool list <tenant-id>                           List tool configs for a tenant
  tool set <tenant-id> <tool-name> <key=value>... Add or update a tool config
  tool delete <tenant-id> <tool-name>             Remove a tool config

  ${colors.dim}Example:${colors.reset}
    kubectl port-forward -n kclaw svc/credrouter 8080:80 &
    kclaw-admin tool set telegram-main brave-search apiKey=BSA-your-key-here
    kclaw-admin tool list telegram-main

${colors.bright}Health:${colors.reset}
  health                                          Check Admin API health

${colors.bright}Options:${colors.reset}
  --force                                         Skip confirmation prompts
  --archive                                       Archive session files before reset

${colors.bright}Environment Variables:${colors.reset}
  ADMIN_API_PORT        Admin API port (default: 3002)
  ADMIN_API_HOST        Admin API host (default: 127.0.0.1)
  ADMIN_API_TOKEN       Bearer token for orchestrator admin auth
  CREDROUTER_URL        CredRouter URL (default: http://127.0.0.1:8080)
  CREDROUTER_ADMIN_TOKEN  Bearer token for CredRouter admin auth (optional)
`);
}

// Run CLI
main().catch((err) => {
  printError(err instanceof Error ? err.message : String(err));
  process.exit(1);
});

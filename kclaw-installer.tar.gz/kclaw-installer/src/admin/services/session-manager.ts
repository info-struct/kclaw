import fs from 'fs';
import path from 'path';

import { CONTAINER_IMAGE, DATA_DIR, GROUPS_DIR } from '../../config.js';
import {
  deleteSession,
  getAllSessionsWithMetadata,
  getSessionWithMetadata,
  markSessionStale,
  SessionWithMetadata,
} from '../../db.js';
import { logger } from '../../logger.js';
import { logAdminAction } from '../../admin-db.js';

export interface StaleSession {
  groupFolder: string;
  sessionId: string;
  containerVersion: string | null;
  currentVersion: string;
  createdAt: string | null;
  lastUsedAt: string | null;
}

export interface SessionInfo {
  groupFolder: string;
  sessionId: string;
  containerVersion: string | null;
  createdAt: string | null;
  lastUsedAt: string | null;
  status: string | null;
  transcriptSize: number;
  transcriptExists: boolean;
  age: number; // milliseconds since creation
}

export interface ResetOptions {
  archive?: boolean;
  adminUser?: string;
  adminIp?: string;
}

export interface ResetResult {
  groupFolder: string;
  success: boolean;
  error?: string;
  archivePath?: string;
}

/**
 * Detect sessions that have a different container version than the current one.
 */
export function detectStaleSessions(): StaleSession[] {
  const sessions = getAllSessionsWithMetadata();
  const currentVersion = CONTAINER_IMAGE;
  const staleSessions: StaleSession[] = [];

  for (const session of sessions) {
    // Session is stale if container_version doesn't match current or is null
    if (
      !session.containerVersion ||
      session.containerVersion !== currentVersion
    ) {
      staleSessions.push({
        groupFolder: session.groupFolder,
        sessionId: session.sessionId,
        containerVersion: session.containerVersion,
        currentVersion,
        createdAt: session.createdAt,
        lastUsedAt: session.lastUsedAt,
      });

      // Mark in database
      markSessionStale(session.groupFolder);
    }
  }

  logger.info(
    { staleCount: staleSessions.length, currentVersion },
    'Detected stale sessions',
  );

  return staleSessions;
}

/**
 * Get detailed information about a specific session.
 */
export function getSessionInfo(groupFolder: string): SessionInfo | null {
  const session = getSessionWithMetadata(groupFolder);
  if (!session) return null;

  const transcriptPath = path.join(
    GROUPS_DIR,
    groupFolder,
    `transcript-${session.sessionId}.jsonl`,
  );
  const transcriptExists = fs.existsSync(transcriptPath);
  const transcriptSize = transcriptExists
    ? fs.statSync(transcriptPath).size
    : 0;

  const createdAt = session.createdAt
    ? new Date(session.createdAt).getTime()
    : Date.now();
  const age = Date.now() - createdAt;

  return {
    groupFolder: session.groupFolder,
    sessionId: session.sessionId,
    containerVersion: session.containerVersion,
    createdAt: session.createdAt,
    lastUsedAt: session.lastUsedAt,
    status: session.status,
    transcriptSize,
    transcriptExists,
    age,
  };
}

/**
 * Archive session files to data/sessions-archive/{groupFolder}/{timestamp}/
 */
export function archiveSessionFiles(
  groupFolder: string,
  sessionId: string,
  timestamp?: string,
): string | null {
  const archiveTimestamp =
    timestamp || new Date().toISOString().replace(/[:.]/g, '-');
  const archiveDir = path.join(
    DATA_DIR,
    'sessions-archive',
    groupFolder,
    archiveTimestamp,
  );

  try {
    fs.mkdirSync(archiveDir, { recursive: true });

    const groupDir = path.join(GROUPS_DIR, groupFolder);
    if (!fs.existsSync(groupDir)) {
      logger.warn(
        { groupFolder },
        'Group directory does not exist, skipping archive',
      );
      return null;
    }

    // Archive transcript file
    const transcriptPath = path.join(groupDir, `transcript-${sessionId}.jsonl`);
    if (fs.existsSync(transcriptPath)) {
      fs.copyFileSync(
        transcriptPath,
        path.join(archiveDir, `transcript-${sessionId}.jsonl`),
      );
    }

    // Archive CLAUDE.md if exists
    const claudeMdPath = path.join(groupDir, 'CLAUDE.md');
    if (fs.existsSync(claudeMdPath)) {
      fs.copyFileSync(claudeMdPath, path.join(archiveDir, 'CLAUDE.md'));
    }

    // Create metadata file
    const metadata = {
      groupFolder,
      sessionId,
      archivedAt: new Date().toISOString(),
      containerVersion: CONTAINER_IMAGE,
    };
    fs.writeFileSync(
      path.join(archiveDir, 'metadata.json'),
      JSON.stringify(metadata, null, 2),
    );

    logger.info({ groupFolder, archiveDir }, 'Session files archived');
    return archiveDir;
  } catch (err) {
    logger.error({ groupFolder, err }, 'Failed to archive session files');
    return null;
  }
}

/**
 * Reset a single session by clearing the database entry and optionally archiving files.
 */
export function resetSession(
  groupFolder: string,
  options: ResetOptions = {},
): ResetResult {
  const { archive = false, adminUser, adminIp } = options;

  try {
    const session = getSessionWithMetadata(groupFolder);
    if (!session) {
      const error = 'Session not found';
      logAdminAction({
        adminUser,
        adminIp,
        action: 'session_reset',
        resourceType: 'session',
        resourceId: groupFolder,
        status: 'error',
        errorMessage: error,
      });
      return { groupFolder, success: false, error };
    }

    let archivePath: string | undefined;

    // Archive if requested
    if (archive) {
      const archived = archiveSessionFiles(groupFolder, session.sessionId);
      if (archived) {
        archivePath = archived;
      }
    }

    // Delete transcript file
    const transcriptPath = path.join(
      GROUPS_DIR,
      groupFolder,
      `transcript-${session.sessionId}.jsonl`,
    );
    if (fs.existsSync(transcriptPath)) {
      fs.unlinkSync(transcriptPath);
      logger.info({ groupFolder, transcriptPath }, 'Transcript file deleted');
    }

    // Clear database entry
    deleteSession(groupFolder);

    logAdminAction({
      adminUser,
      adminIp,
      action: 'session_reset',
      resourceType: 'session',
      resourceId: groupFolder,
      details: {
        sessionId: session.sessionId,
        archived: archive,
        archivePath,
      },
      status: 'success',
    });

    logger.info(
      { groupFolder, sessionId: session.sessionId, archived: archive },
      'Session reset successfully',
    );

    return { groupFolder, success: true, archivePath };
  } catch (err) {
    const error = err instanceof Error ? err.message : String(err);
    logger.error({ groupFolder, err }, 'Failed to reset session');

    logAdminAction({
      adminUser,
      adminIp,
      action: 'session_reset',
      resourceType: 'session',
      resourceId: groupFolder,
      status: 'error',
      errorMessage: error,
    });

    return { groupFolder, success: false, error };
  }
}

export interface ResetAllOptions extends ResetOptions {
  staleOnly?: boolean;
}

/**
 * Reset multiple sessions with optional filters.
 */
export function resetAllSessions(options: ResetAllOptions = {}): ResetResult[] {
  const { staleOnly = false, archive = false, adminUser, adminIp } = options;

  const sessions = staleOnly
    ? detectStaleSessions().map((s) => s.groupFolder)
    : getAllSessionsWithMetadata().map((s) => s.groupFolder);

  logger.info(
    { count: sessions.length, staleOnly, archive },
    'Resetting multiple sessions',
  );

  const results = sessions.map((groupFolder) =>
    resetSession(groupFolder, { archive, adminUser, adminIp }),
  );

  const successCount = results.filter((r) => r.success).length;
  const failCount = results.filter((r) => !r.success).length;

  logAdminAction({
    adminUser,
    adminIp,
    action: 'session_reset_bulk',
    resourceType: 'session',
    details: {
      total: sessions.length,
      success: successCount,
      failed: failCount,
      staleOnly,
      archived: archive,
    },
    status: failCount > 0 ? 'error' : 'success',
    errorMessage:
      failCount > 0 ? `${failCount} sessions failed to reset` : undefined,
  });

  return results;
}
